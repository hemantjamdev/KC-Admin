import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../app/app_routes.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_radius.dart';
import '../../../../core/constants/app_spacing.dart';
import '../../../../core/navigation/navigation_extensions.dart';
import '../../../../core/widgets/status_chip.dart';
import '../../domain/models/customer_model.dart';
import '../../../stitching/application/providers/stitching_providers.dart';
import '../../../stitching/domain/models/stitching_order_model.dart';

/// Admin Customer Details Page — shows identity, contact details, stitching requests, and system metadata.
class AdminCustomerDetailsPage extends ConsumerWidget {
  const AdminCustomerDetailsPage({super.key, required this.customer});
  final CustomerModel customer;

  String get _initials {
    final parts = customer.displayName.trim().split(' ');
    if (parts.length >= 2) {
      return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    }
    return customer.displayName
        .substring(0, customer.displayName.length.clamp(1, 2))
        .toUpperCase();
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year} at ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final customerKey = customer.firebaseUid ?? customer.id;
    final ordersAsync = ref.watch(customerOrderListProvider(customerKey));
    final allAdminOrders = ref.watch(adminOrderListProvider).valueOrNull ?? [];

    // Combine orders matching customer ID or Firebase UID
    final customerOrders = ordersAsync.valueOrNull ??
        allAdminOrders
            .where((o) =>
                o.customerId == customer.id ||
                (customer.firebaseUid != null &&
                    o.customerId == customer.firebaseUid))
            .toList();

    final activeOrdersCount = customerOrders
        .where((o) => o.status != StitchingOrderStatus.completed)
        .length;

    return PopScope(
      canPop: context.canPop(),
      onPopInvokedWithResult: (didPop, _) {
        if (didPop) return;
        if (context.mounted) context.popOrGo(AppRoutes.adminCustomerList);
      },
      child: Scaffold(
        backgroundColor: AppColors.background,
        appBar: AppBar(
          title: const Text(
            'Customer Profile',
            style: TextStyle(
              color: AppColors.textPrimary,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          leading: IconButton(
            icon: const Icon(
              Icons.arrow_back_rounded,
              color: AppColors.textPrimary,
            ),
            onPressed: () => context.popOrGo(AppRoutes.adminCustomerList),
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.edit_rounded, color: AppColors.primary),
              tooltip: 'Edit Profile',
              onPressed: () =>
                  context.push(AppRoutes.adminCustomerEdit, extra: customer),
            ),
          ],
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.all(AppSpacing.lg),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 560),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Identity Header Card
                    Container(
                      padding: const EdgeInsets.all(AppSpacing.xl),
                      decoration: BoxDecoration(
                        color: AppColors.surface,
                        borderRadius: AppRadius.borderXl,
                        border: Border.all(color: AppColors.surfaceBorder),
                      ),
                      child: Column(
                        children: [
                          CircleAvatar(
                            radius: 36,
                            backgroundColor: AppColors.surfaceLight,
                            backgroundImage: customer.photoUrl != null
                                ? NetworkImage(customer.photoUrl!)
                                : null,
                            child: customer.photoUrl == null
                                ? Text(
                                    _initials,
                                    style: const TextStyle(
                                      color: AppColors.primary,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 24,
                                    ),
                                  )
                                : null,
                          ),
                          const SizedBox(height: AppSpacing.md),
                          Text(
                            customer.displayName,
                            style: const TextStyle(
                              color: AppColors.textPrimary,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: AppSpacing.xs),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              _Badge(
                                label: customer.source.label,
                                color: customer.source == CustomerSource.google
                                    ? AppColors.primary
                                    : AppColors.warning,
                              ),
                              const SizedBox(width: AppSpacing.xs),
                              _Badge(
                                label: customer.isActive
                                    ? 'Active'
                                    : 'Inactive',
                                color: customer.isActive
                                    ? AppColors.success
                                    : AppColors.error,
                              ),
                              if (customer.isFirebaseLinked) ...[
                                const SizedBox(width: AppSpacing.xs),
                                const _Badge(
                                  label: 'Firebase Linked',
                                  color: AppColors.success,
                                ),
                              ],
                            ],
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: AppSpacing.lg),

                    // Contact Details Section
                    _infoCard('Contact Details', [
                      _infoRow(
                        'Email Address',
                        customer.email ?? 'Not provided',
                      ),
                      _infoRow(
                        'Phone Number',
                        customer.phone ?? 'Not provided',
                      ),
                    ]),

                    const SizedBox(height: AppSpacing.md),

                    // ── STITCHING REQUESTS SECTION ─────────────────────
                    Container(
                      padding: const EdgeInsets.all(AppSpacing.lg),
                      decoration: BoxDecoration(
                        color: AppColors.surface,
                        borderRadius: AppRadius.borderLg,
                        border: Border.all(color: AppColors.surfaceBorder),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  const Icon(
                                    Icons.cut_rounded,
                                    size: 18,
                                    color: AppColors.primary,
                                  ),
                                  const SizedBox(width: 8),
                                  Text(
                                    'Stitching Requests (${customerOrders.length})',
                                    style: const TextStyle(
                                      color: AppColors.primary,
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 0.5,
                                    ),
                                  ),
                                ],
                              ),
                              ElevatedButton.icon(
                                onPressed: () => context.push(
                                  AppRoutes.adminStitchingOrderAdd,
                                  extra: customer,
                                ),
                                icon: const Icon(Icons.add_rounded, size: 16),
                                label: const Text(
                                  'New Request',
                                  style: TextStyle(fontSize: 12),
                                ),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: AppColors.primary,
                                  foregroundColor: AppColors.surfaceWhite,
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 10,
                                    vertical: 6,
                                  ),
                                  minimumSize: Size.zero,
                                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: AppSpacing.md),

                          // Quick Summary Stats Row
                          Container(
                            padding: const EdgeInsets.all(AppSpacing.md),
                            decoration: BoxDecoration(
                              color: AppColors.surfaceLight,
                              borderRadius: AppRadius.borderMd,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                _statItem(
                                  'Total Orders',
                                  '${customerOrders.length}',
                                  AppColors.primary,
                                ),
                                _statItem(
                                  'In Progress',
                                  '$activeOrdersCount',
                                  AppColors.warning,
                                ),
                                _statItem(
                                  'Completed',
                                  '${customerOrders.where((o) => o.status == StitchingOrderStatus.completed).length}',
                                  AppColors.success,
                                ),
                              ],
                            ),
                          ),

                          const SizedBox(height: AppSpacing.md),

                          // Orders List
                          if (customerOrders.isEmpty)
                            Padding(
                              padding: const EdgeInsets.symmetric(vertical: 16),
                              child: Center(
                                child: Column(
                                  children: [
                                    const Icon(
                                      Icons.checkroom_outlined,
                                      size: 32,
                                      color: AppColors.textMuted,
                                    ),
                                    const SizedBox(height: 8),
                                    const Text(
                                      'No stitching requests for this customer yet.',
                                      style: TextStyle(
                                        color: AppColors.textMuted,
                                        fontSize: 12,
                                      ),
                                    ),
                                    const SizedBox(height: 12),
                                    OutlinedButton.icon(
                                      onPressed: () => context.push(
                                        AppRoutes.adminStitchingOrderAdd,
                                        extra: customer,
                                      ),
                                      icon: const Icon(Icons.add_rounded, size: 16),
                                      label: const Text(
                                        'Create First Request',
                                        style: TextStyle(fontSize: 12),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            )
                          else
                            ListView.separated(
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              itemCount: customerOrders.length,
                              separatorBuilder: (_, _) => const Divider(
                                color: AppColors.surfaceBorder,
                                height: AppSpacing.md,
                              ),
                              itemBuilder: (context, index) {
                                final order = customerOrders[index];
                                return InkWell(
                                  onTap: () => context.push(
                                    AppRoutes.adminStitchingOrderDetails,
                                    extra: order,
                                  ),
                                  borderRadius: AppRadius.borderMd,
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                      vertical: 4,
                                    ),
                                    child: Row(
                                      children: [
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Row(
                                                children: [
                                                  Text(
                                                    order.orderNumber,
                                                    style: const TextStyle(
                                                      color: AppColors.textPrimary,
                                                      fontWeight: FontWeight.bold,
                                                      fontSize: 14,
                                                    ),
                                                  ),
                                                  const SizedBox(width: 8),
                                                  StitchingStatusChip(
                                                    label: order.status.adminLabel,
                                                    color: stitchingStatusColor(order.status.name),
                                                  ),
                                                ],
                                              ),
                                              const SizedBox(height: 4),
                                              Text(
                                                order.designReferences.isNotEmpty
                                                    ? order.designReferences
                                                        .map((d) => d.designName)
                                                        .join(', ')
                                                    : 'Custom Tailoring',
                                                style: const TextStyle(
                                                  color: AppColors.textMuted,
                                                  fontSize: 12,
                                                ),
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                            ],
                                          ),
                                        ),
                                        const Icon(
                                          Icons.chevron_right_rounded,
                                          color: AppColors.textMuted,
                                          size: 20,
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            ),
                        ],
                      ),
                    ),

                    const SizedBox(height: AppSpacing.md),

                    // System Metadata & Audit
                    _infoCard('System Metadata', [
                      _infoRow('Customer Document ID', customer.id),
                      _infoRow(
                        'Firebase Auth UID',
                        customer.firebaseUid ?? 'Not linked',
                      ),
                      _infoRow('Created At', _formatDate(customer.createdAt)),
                      _infoRow('Updated At', _formatDate(customer.updatedAt)),
                      _infoRow('Created By', customer.createdBy ?? 'System'),
                      _infoRow('Updated By', customer.updatedBy ?? 'System'),
                    ]),

                    const SizedBox(height: AppSpacing.xl),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _statItem(String label, String count, Color color) {
    return Column(
      children: [
        Text(
          count,
          style: TextStyle(
            color: color,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: const TextStyle(
            color: AppColors.textMuted,
            fontSize: 11,
          ),
        ),
      ],
    );
  }

  Widget _infoCard(String title, List<Widget> children) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.lg),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: AppRadius.borderLg,
        border: Border.all(color: AppColors.surfaceBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: AppColors.primary,
              fontSize: 13,
              fontWeight: FontWeight.bold,
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: AppSpacing.md),
          ...children,
        ],
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppSpacing.sm),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 150,
            child: Text(
              label,
              style: const TextStyle(color: AppColors.textMuted, fontSize: 12),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                color: AppColors.textPrimary,
                fontSize: 13,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  const _Badge({required this.label, required this.color});
  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: AppSpacing.sm, vertical: 2),
    decoration: BoxDecoration(
      color: color.withValues(alpha: 0.15),
      borderRadius: AppRadius.borderPill,
    ),
    child: Text(
      label,
      style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.bold),
    ),
  );
}
