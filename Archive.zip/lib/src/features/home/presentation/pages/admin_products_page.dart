import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/widgets/app_full_screen_image_dialog.dart';
import '../../../design/application/providers/design_providers.dart';
import '../../../design/domain/models/design_model.dart';

/// Admin Products Page — simple, clean, search-filtered listing of all products.
/// Includes product details sheet on tap, with no add buttons or clutter.
class AdminProductsPage extends ConsumerStatefulWidget {
  const AdminProductsPage({super.key});

  @override
  ConsumerState<AdminProductsPage> createState() => _AdminProductsPageState();
}

class _AdminProductsPageState extends ConsumerState<AdminProductsPage> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _showProductDetails(BuildContext context, DesignModel design) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => _ProductDetailsSheet(design: design),
    );
  }

  @override
  Widget build(BuildContext context) {
    final designsAsync = ref.watch(designListProvider);
    final designs = designsAsync.valueOrNull ?? [];
    final isLoading = designsAsync.isLoading;

    final filteredDesigns = designs.where((d) {
      if (_searchQuery.trim().isEmpty) return true;
      final q = _searchQuery.toLowerCase().trim();
      final nameMatch = d.name.toLowerCase().contains(q);
      final descMatch =
          (d.description ?? '').toLowerCase().contains(q) ||
          (d.shortDescription ?? '').toLowerCase().contains(q);
      final tagMatch = d.tags.any((t) => t.toLowerCase().contains(q));
      return nameMatch || descMatch || tagMatch;
    }).toList();

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: RefreshIndicator(
          color: AppColors.primary,
          onRefresh: () async {
            ref.invalidate(designListProvider);
            await ref.read(designListProvider.future);
          },
          child: CustomScrollView(
            physics: const AlwaysScrollableScrollPhysics(
              parent: BouncingScrollPhysics(),
            ),
            slivers: [
              // ── Header (Title & Subtitle - No Add Buttons) ──────────────
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Products',
                        style: GoogleFonts.playfairDisplay(
                          fontSize: 28,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'Browse all boutique products and apparel',
                        style: GoogleFonts.montserrat(
                          fontSize: 12,
                          color: AppColors.textMuted,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // ── Search Field ───────────────────────────────────────────
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 4, 20, 16),
                  child: TextField(
                    controller: _searchController,
                    onChanged: (val) {
                      setState(() {
                        _searchQuery = val;
                      });
                    },
                    style: GoogleFonts.montserrat(
                      fontSize: 14,
                      color: AppColors.textPrimary,
                    ),
                    decoration: InputDecoration(
                      hintText: 'Search products by name or tag...',
                      hintStyle: GoogleFonts.montserrat(
                        fontSize: 13,
                        color: AppColors.textHint,
                      ),
                      prefixIcon: const Icon(
                        Icons.search_rounded,
                        color: AppColors.textMuted,
                        size: 20,
                      ),
                      suffixIcon: _searchQuery.isNotEmpty
                          ? IconButton(
                              icon: const Icon(
                                Icons.clear_rounded,
                                color: AppColors.textMuted,
                                size: 20,
                              ),
                              onPressed: () {
                                _searchController.clear();
                                setState(() {
                                  _searchQuery = '';
                                });
                              },
                            )
                          : null,
                      filled: true,
                      fillColor: AppColors.surface,
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: const BorderSide(
                          color: AppColors.surfaceBorder,
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: const BorderSide(
                          color: AppColors.surfaceBorder,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: const BorderSide(
                          color: AppColors.primary,
                          width: 1.5,
                        ),
                      ),
                    ),
                  ),
                ),
              ),

              // ── Product Grid / List Content ──────────────────────────────
              if (isLoading)
                const SliverFillRemaining(
                  child: Center(
                    child: CircularProgressIndicator(
                      color: AppColors.primary,
                      strokeWidth: 2.5,
                    ),
                  ),
                )
              else if (filteredDesigns.isEmpty)
                SliverFillRemaining(
                  hasScrollBody: false,
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Center(
                      child: Container(
                        padding: const EdgeInsets.all(28),
                        decoration: BoxDecoration(
                          color: AppColors.surface,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: AppColors.surfaceBorder),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.02),
                              blurRadius: 10,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              width: 60,
                              height: 60,
                              decoration: BoxDecoration(
                                color: AppColors.primary.withValues(
                                  alpha: 0.1,
                                ),
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(
                                Icons.inventory_2_outlined,
                                size: 28,
                                color: AppColors.primary,
                              ),
                            ),
                            const SizedBox(height: 16),
                            Text(
                              _searchQuery.isNotEmpty
                                  ? 'No Matching Products'
                                  : 'No Products Catalogue',
                              style: GoogleFonts.playfairDisplay(
                                fontSize: 18,
                                fontWeight: FontWeight.w700,
                                color: AppColors.textPrimary,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              _searchQuery.isNotEmpty
                                  ? 'No product matches "$_searchQuery". Try searching with another name or tag.'
                                  : 'There are no products currently available in the catalogue.',
                              style: GoogleFonts.montserrat(
                                fontSize: 12,
                                color: AppColors.textMuted,
                                height: 1.4,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                )
              else
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
                  sliver: SliverList.separated(
                    itemCount: filteredDesigns.length,
                    separatorBuilder: (context, index) =>
                        const SizedBox(height: 12),
                    itemBuilder: (context, index) {
                      final design = filteredDesigns[index];
                      return _ProductCardTile(
                        design: design,
                        onTap: () => _showProductDetails(context, design),
                      );
                    },
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

// ── Product List Tile ─────────────────────────────────────────────────────────

class _ProductCardTile extends StatelessWidget {
  const _ProductCardTile({required this.design, required this.onTap});

  final DesignModel design;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final hasImage =
        design.thumbnailUrl != null && design.thumbnailUrl!.isNotEmpty ||
        design.imageUrls.isNotEmpty;
    final imageUrl = hasImage
        ? (design.thumbnailUrl != null && design.thumbnailUrl!.isNotEmpty
            ? design.thumbnailUrl!
            : design.imageUrls.first)
        : null;

    final primaryTag = design.tags.isNotEmpty ? design.tags.first : 'Bespoke';

    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.surfaceBorder),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.02),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            // Image / Thumbnail
            Container(
              width: 76,
              height: 76,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: AppColors.background,
              ),
              clipBehavior: Clip.antiAlias,
              child: imageUrl != null
                  ? Image.network(
                      imageUrl,
                      fit: BoxFit.cover,
                      errorBuilder: (ctx, err, stack) => _imageFallback(),
                    )
                  : _imageFallback(),
            ),
            const SizedBox(width: 14),

            // Title & Details
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        primaryTag.toUpperCase(),
                        style: GoogleFonts.montserrat(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: AppColors.primary,
                          letterSpacing: 0.8,
                        ),
                      ),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: design.isActive
                              ? const Color(0xFF2E7D32).withValues(alpha: 0.15)
                              : AppColors.textMuted.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          design.isActive ? 'Active' : 'Inactive',
                          style: GoogleFonts.montserrat(
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                            color: design.isActive
                                ? const Color(0xFF2E7D32)
                                : AppColors.textMuted,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    design.name,
                    style: GoogleFonts.playfairDisplay(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '₹${design.price.toInt()}',
                    style: GoogleFonts.montserrat(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: AppColors.primary,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            const Icon(
              Icons.chevron_right_rounded,
              color: AppColors.textMuted,
              size: 20,
            ),
          ],
        ),
      ),
    );
  }

  Widget _imageFallback() {
    return Container(
      color: AppColors.background,
      child: const Center(
        child: Icon(
          Icons.checkroom_rounded,
          color: AppColors.textMuted,
          size: 26,
        ),
      ),
    );
  }
}

// ── Product Details Modal Sheet ───────────────────────────────────────────────

class _ProductDetailsSheet extends ConsumerStatefulWidget {
  const _ProductDetailsSheet({required this.design});

  final DesignModel design;

  @override
  ConsumerState<_ProductDetailsSheet> createState() =>
      _ProductDetailsSheetState();
}

class _ProductDetailsSheetState extends ConsumerState<_ProductDetailsSheet> {
  late bool _isActive;
  bool _isTogglingStock = false;

  @override
  void initState() {
    super.initState();
    _isActive = widget.design.isActive;
  }

  Future<void> _toggleStockStatus() async {
    final newStatus = !_isActive;
    setState(() {
      _isTogglingStock = true;
      _isActive = newStatus;
    });

    try {
      final updated = widget.design.copyWith(
        isActive: newStatus,
        updatedAt: DateTime.now(),
      );
      await ref.read(designMutationProvider.notifier).update(updated);
      ref.invalidate(designListProvider);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            margin: const EdgeInsets.all(16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
            backgroundColor: const Color(0xFF1F2937),
            content: Row(
              children: [
                Icon(
                  newStatus
                      ? Icons.check_circle_rounded
                      : Icons.remove_shopping_cart_rounded,
                  color: newStatus
                      ? const Color(0xFF4ADE80)
                      : const Color(0xFFF87171),
                  size: 20,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    newStatus
                        ? '"${widget.design.name}" is now available for ordering.'
                        : '"${widget.design.name}" marked as Out of Stock.',
                    style: GoogleFonts.montserrat(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      }
    } catch (_) {
      // Revert on failure
      if (mounted) setState(() => _isActive = !newStatus);
    } finally {
      if (mounted) setState(() => _isTogglingStock = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final design = widget.design;

    final hasImage =
        design.thumbnailUrl != null && design.thumbnailUrl!.isNotEmpty ||
        design.imageUrls.isNotEmpty;
    final imageUrl = hasImage
        ? (design.thumbnailUrl != null && design.thumbnailUrl!.isNotEmpty
            ? design.thumbnailUrl!
            : design.imageUrls.first)
        : null;

    final formattedDate = DateFormat('dd MMM yyyy').format(design.createdAt);

    return DraggableScrollableSheet(
      initialChildSize: 0.80,
      minChildSize: 0.5,
      maxChildSize: 0.95,
      expand: false,
      builder: (ctx, scrollController) {
        return Column(
          children: [
            const SizedBox(height: 12),
            Center(
              child: Container(
                width: 36,
                height: 4,
                decoration: BoxDecoration(
                  color: AppColors.surfaceBorder,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: ListView(
                controller: scrollController,
                padding: const EdgeInsets.symmetric(horizontal: 24),
                children: [
                  // Image Preview Banner
                  GestureDetector(
                    onTap: () {
                      final urls = design.imageUrls.isNotEmpty
                          ? design.imageUrls
                          : (imageUrl != null ? [imageUrl] : <String>[]);
                      if (urls.isNotEmpty) {
                        AppFullScreenImageDialog.show(context, imageUrls: urls);
                      }
                    },
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(18),
                      child: Container(
                        height: 220,
                        width: double.infinity,
                        decoration: const BoxDecoration(
                          color: AppColors.surfaceBorder,
                        ),
                        child: imageUrl != null
                            ? Image.network(
                                imageUrl,
                                fit: BoxFit.cover,
                                errorBuilder: (ctx, err, stack) => _sheetFallback(),
                              )
                            : _sheetFallback(),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Header info
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              design.name,
                              style: GoogleFonts.playfairDisplay(
                                fontSize: 22,
                                fontWeight: FontWeight.w700,
                                color: AppColors.textPrimary,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Added on $formattedDate',
                              style: GoogleFonts.montserrat(
                                fontSize: 11,
                                color: AppColors.textMuted,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: AppColors.primary.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          '₹${design.price.toStringAsFixed(0)}',
                          style: GoogleFonts.montserrat(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            color: AppColors.primary,
                          ),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),
                  const Divider(color: AppColors.surfaceBorder),
                  const SizedBox(height: 12),

                  // ── Out of Stock Toggle ────────────────────────────────────
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 14,
                    ),
                    decoration: BoxDecoration(
                      color: _isActive
                          ? const Color(0xFF14532D).withValues(alpha: 0.1)
                          : const Color(0xFF7F1D1D).withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: _isActive
                            ? const Color(0xFF4ADE80).withValues(alpha: 0.4)
                            : const Color(0xFFF87171).withValues(alpha: 0.4),
                      ),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: _isActive
                                ? const Color(0xFF4ADE80).withValues(alpha: 0.15)
                                : const Color(0xFFF87171).withValues(alpha: 0.15),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            _isActive
                                ? Icons.check_circle_rounded
                                : Icons.remove_shopping_cart_rounded,
                            color: _isActive
                                ? const Color(0xFF16A34A)
                                : const Color(0xFFDC2626),
                            size: 20,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                _isActive ? 'Available for Orders' : 'Out of Stock',
                                style: GoogleFonts.montserrat(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w700,
                                  color: _isActive
                                      ? const Color(0xFF16A34A)
                                      : const Color(0xFFDC2626),
                                ),
                              ),
                              Text(
                                _isActive
                                    ? 'Customers can view & request this product'
                                    : 'Hidden from customers on the app',
                                style: GoogleFonts.montserrat(
                                  fontSize: 11,
                                  color: AppColors.textMuted,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 8),
                        _isTogglingStock
                            ? const SizedBox(
                                width: 24,
                                height: 24,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2.5,
                                  color: AppColors.primary,
                                ),
                              )
                            : Switch.adaptive(
                                value: _isActive,
                                onChanged: (_) => _toggleStockStatus(),
                                activeTrackColor: const Color(0xFF16A34A),
                                inactiveThumbColor: const Color(0xFFDC2626),
                                inactiveTrackColor:
                                    const Color(0xFFFCA5A5).withValues(alpha: 0.4),
                              ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 16),
                  const Divider(color: AppColors.surfaceBorder),
                  const SizedBox(height: 12),

                  // Description
                  if ((design.description ?? '').isNotEmpty ||
                      (design.shortDescription ?? '').isNotEmpty) ...[
                    Text(
                      'DESCRIPTION',
                      style: GoogleFonts.montserrat(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textMuted,
                        letterSpacing: 1.2,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      design.description?.isNotEmpty == true
                          ? design.description!
                          : (design.shortDescription ?? ''),
                      style: GoogleFonts.montserrat(
                        fontSize: 13,
                        color: AppColors.textPrimary,
                        height: 1.5,
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],

                  // Colors
                  if (design.colors.isNotEmpty) ...[
                    Text(
                      'AVAILABLE COLORS',
                      style: GoogleFonts.montserrat(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textMuted,
                        letterSpacing: 1.2,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: design.colors.map((hex) {
                        Color c = AppColors.primary;
                        try {
                          c = Color(
                            int.parse(
                              hex.replaceFirst('#', 'FF'),
                              radix: 16,
                            ),
                          );
                        } catch (_) {}
                        return Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              width: 16,
                              height: 16,
                              decoration: BoxDecoration(
                                color: c,
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: AppColors.surfaceBorder,
                                ),
                              ),
                            ),
                            const SizedBox(width: 6),
                            Text(
                              hex,
                              style: GoogleFonts.montserrat(
                                fontSize: 12,
                                color: AppColors.textPrimary,
                              ),
                            ),
                          ],
                        );
                      }).toList(),
                    ),
                    const SizedBox(height: 12),
                  ],

                  // Sizes
                  if (design.sizes.isNotEmpty) ...[
                    Text(
                      'SIZES',
                      style: GoogleFonts.montserrat(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textMuted,
                        letterSpacing: 1.2,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 8,
                      children: design.sizes
                          .map(
                            (s) => Chip(
                              label: Text(
                                s,
                                style: GoogleFonts.montserrat(fontSize: 11),
                              ),
                              backgroundColor: AppColors.background,
                              side: const BorderSide(
                                color: AppColors.surfaceBorder,
                              ),
                            ),
                          )
                          .toList(),
                    ),
                    const SizedBox(height: 12),
                  ],

                  // Tags
                  if (design.tags.isNotEmpty) ...[
                    Text(
                      'TAGS & CATEGORIES',
                      style: GoogleFonts.montserrat(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textMuted,
                        letterSpacing: 1.2,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      children: design.tags
                          .map(
                            (t) => Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: AppColors.primary.withValues(
                                  alpha: 0.08,
                                ),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                '#$t',
                                style: GoogleFonts.montserrat(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.primary,
                                ),
                              ),
                            ),
                          )
                          .toList(),
                    ),
                  ],

                  const SizedBox(height: 32),
                ],
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _sheetFallback() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF0F3625), Color(0xFF1B593F)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: const Center(
        child: Icon(
          Icons.style_outlined,
          size: 54,
          color: Color(0xFFD4AF37),
        ),
      ),
    );
  }
}

