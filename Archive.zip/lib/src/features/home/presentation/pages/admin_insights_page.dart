import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/widgets/admin_empty_state.dart';
import '../../../design/application/providers/design_providers.dart';
import '../../../design/application/providers/insights_providers.dart';
import '../../../section/application/providers/section_providers.dart';

/// Admin Performance Insights screen.
/// Shows engagement metrics derived from existing Firestore data.
/// Shows empty states gracefully when data is unavailable.
class AdminInsightsPage extends ConsumerWidget {
  const AdminInsightsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final timeRange = ref.watch(insightsTimeRangeProvider);
    final topDesigns = ref.watch(topDesignsProvider);
    final popularColors = ref.watch(popularColorsProvider);
    final popularSizes = ref.watch(popularSizesProvider);
    final sections = ref.watch(sectionListProvider).valueOrNull ?? [];
    final designsAsync = ref.watch(designListProvider);
    final mostActiveSection = ref.watch(mostActiveSectionProvider);

    final totalActive =
        designsAsync.valueOrNull?.where((d) => d.isActive).length ?? 0;

    return Scaffold(
      backgroundColor: AppColors.warmIvory,
      body: SafeArea(
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            // ── Header ─────────────────────────────────────────
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Insights',
                      style: GoogleFonts.playfairDisplay(
                        fontSize: 30,
                        fontWeight: FontWeight.w700,
                        color: AppColors.charcoal,
                      ),
                    ),
                    Text(
                      'Your boutique at a glance',
                      style: GoogleFonts.montserrat(
                        fontSize: 13,
                        fontStyle: FontStyle.italic,
                        color: AppColors.mutedText,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // ── Time Range Filter ───────────────────────────────
            SliverToBoxAdapter(
              child: SizedBox(
                height: 40,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  children: InsightsTimeRange.values.map((range) {
                    final isActive = timeRange == range;
                    return GestureDetector(
                      onTap: () => ref
                          .read(insightsTimeRangeProvider.notifier)
                          .select(range),
                      child: Container(
                        margin: const EdgeInsets.only(right: 8),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color: isActive
                              ? AppColors.brandGreen900
                              : AppColors.surfaceWhite,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: isActive
                                ? AppColors.brandGreen900
                                : AppColors.borderSoft,
                          ),
                        ),
                        child: Text(
                          range.label,
                          style: GoogleFonts.montserrat(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: isActive
                                ? AppColors.surfaceWhite
                                : AppColors.charcoal,
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
            ),

            const SliverToBoxAdapter(child: SizedBox(height: 16)),

            // ── Engagement Cards Row ────────────────────────────
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: [
                    Expanded(
                      child: _MetricCard(
                        icon: Icons.visibility_outlined,
                        label: 'Active Products',
                        value: '$totalActive',
                        subtitle: 'In catalogue',
                        iconColor: AppColors.brandGreen700,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _MetricCard(
                        icon: Icons.favorite_outline_rounded,
                        label: 'Collections',
                        value: '${sections.length}',
                        subtitle: 'Total sections',
                        iconColor: const Color(0xFFCC4B37),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SliverToBoxAdapter(child: SizedBox(height: 16)),

            // ── Season Peak Banner ──────────────────────────────
            if (mostActiveSection != null)
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: _SeasonPeakBanner(
                    sectionName: mostActiveSection.title,
                  ),
                ),
              ),

            const SliverToBoxAdapter(child: SizedBox(height: 16)),

            // ── Top Curated Products ────────────────────────────
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'RECENTLY ACTIVE PRODUCTS',
                      style: GoogleFonts.montserrat(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: AppColors.mutedText,
                        letterSpacing: 1.2,
                      ),
                    ),
                    const SizedBox(height: 12),
                    if (topDesigns.isEmpty)
                      AdminEmptyState(
                        icon: Icons.design_services_outlined,
                        title: 'No active products',
                        subtitle:
                            'Add products to see performance insights here.',
                      )
                    else
                      ...topDesigns.asMap().entries.map(
                        (entry) => _ProductInsightTile(
                          rank: entry.key + 1,
                          design: entry.value,
                        ),
                      ),
                  ],
                ),
              ),
            ),

            const SliverToBoxAdapter(child: SizedBox(height: 24)),

            // ── Popular Palettes ────────────────────────────────
            if (popularColors.isNotEmpty)
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: _ColorPaletteSection(colors: popularColors),
                ),
              ),

            const SliverToBoxAdapter(child: SizedBox(height: 16)),

            // ── Popular Sizes ───────────────────────────────────
            if (popularSizes.isNotEmpty)
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: _PopularSizesSection(sizes: popularSizes),
                ),
              ),

            const SliverToBoxAdapter(child: SizedBox(height: 16)),

            // ── Section Engagement ──────────────────────────────
            if (sections.isNotEmpty)
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: _SectionEngagementSection(sections: sections),
                ),
              ),

            // ── Empty state when no data at all ────────────────
            if (topDesigns.isEmpty && popularColors.isEmpty && sections.isEmpty)
              SliverFillRemaining(
                child: AdminEmptyState(
                  icon: Icons.bar_chart_outlined,
                  title: 'Insights are loading',
                  subtitle:
                      'Insights will appear after customers start viewing and favoriting products.',
                ),
              ),

            const SliverToBoxAdapter(child: SizedBox(height: 32)),
          ],
        ),
      ),
    );
  }
}

// ── Metric Card ───────────────────────────────────────────────────────────────

class _MetricCard extends StatelessWidget {
  const _MetricCard({
    required this.icon,
    required this.label,
    required this.value,
    required this.subtitle,
    required this.iconColor,
  });

  final IconData icon;
  final String label;
  final String value;
  final String subtitle;
  final Color iconColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.surfaceWhite,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.borderSoft),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 18, color: iconColor),
              const Spacer(),
              Text(
                label,
                style: GoogleFonts.montserrat(
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                  color: AppColors.mutedText,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            value,
            style: GoogleFonts.playfairDisplay(
              fontSize: 28,
              fontWeight: FontWeight.w700,
              color: AppColors.charcoal,
            ),
          ),
          Text(
            subtitle,
            style: GoogleFonts.montserrat(
              fontSize: 11,
              color: AppColors.mutedText,
            ),
          ),
        ],
      ),
    );
  }
}

// ── Season Peak Banner ────────────────────────────────────────────────────────

class _SeasonPeakBanner extends StatelessWidget {
  const _SeasonPeakBanner({required this.sectionName});

  final String sectionName;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.brandGreen900,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          const Icon(
            Icons.trending_up_rounded,
            color: AppColors.mutedGold,
            size: 28,
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'SEASON PEAK',
                  style: GoogleFonts.montserrat(
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    color: AppColors.mutedGold,
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  sectionName,
                  style: GoogleFonts.playfairDisplay(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: AppColors.surfaceWhite,
                    fontStyle: FontStyle.italic,
                  ),
                ),
                Text(
                  'Your most featured collection',
                  style: GoogleFonts.montserrat(
                    fontSize: 11,
                    color: AppColors.brandGreen100,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ── Product Insight Tile ──────────────────────────────────────────────────────

class _ProductInsightTile extends StatelessWidget {
  const _ProductInsightTile({required this.rank, required this.design});

  final int rank;
  final dynamic design;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surfaceWhite,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.borderSoft),
      ),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: rank == 1
                  ? AppColors.brandGreen900
                  : AppColors.brandGreen50,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Center(
              child: Text(
                '$rank',
                style: GoogleFonts.playfairDisplay(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: rank == 1
                      ? AppColors.surfaceWhite
                      : AppColors.brandGreen800,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  design.name as String,
                  style: GoogleFonts.montserrat(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: AppColors.charcoal,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                Text(
                  design.isActive ? 'Active' : 'Inactive',
                  style: GoogleFonts.montserrat(
                    fontSize: 11,
                    color: design.isActive
                        ? AppColors.success
                        : AppColors.mutedText,
                  ),
                ),
              ],
            ),
          ),
          if (design.price > 0)
            Text(
              '₹${design.price.toStringAsFixed(0)}',
              style: GoogleFonts.montserrat(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                color: AppColors.brandGreen800,
              ),
            ),
        ],
      ),
    );
  }
}

// ── Color Palette Section ─────────────────────────────────────────────────────

class _ColorPaletteSection extends StatelessWidget {
  const _ColorPaletteSection({required this.colors});

  final Map<String, int> colors;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'POPULAR PALETTES',
          style: GoogleFonts.montserrat(
            fontSize: 10,
            fontWeight: FontWeight.w700,
            color: AppColors.mutedText,
            letterSpacing: 1.2,
          ),
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.surfaceWhite,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.borderSoft),
          ),
          child: Wrap(
            spacing: 8,
            runSpacing: 8,
            children: colors.entries.take(8).map((e) {
              return Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: AppColors.brandGreen50,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppColors.borderSoft),
                ),
                child: Text(
                  '${e.key} (${e.value})',
                  style: GoogleFonts.montserrat(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: AppColors.brandGreen800,
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }
}

// ── Popular Sizes Section ─────────────────────────────────────────────────────

class _PopularSizesSection extends StatelessWidget {
  const _PopularSizesSection({required this.sizes});

  final Map<String, int> sizes;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'REQUESTED SIZES',
          style: GoogleFonts.montserrat(
            fontSize: 10,
            fontWeight: FontWeight.w700,
            color: AppColors.mutedText,
            letterSpacing: 1.2,
          ),
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.surfaceWhite,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.borderSoft),
          ),
          child: Wrap(
            spacing: 8,
            runSpacing: 8,
            children: sizes.entries.map((e) {
              return Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: AppColors.brandGreen900,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      e.key,
                      style: GoogleFonts.montserrat(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: AppColors.surfaceWhite,
                      ),
                    ),
                    Text(
                      '${e.value}x',
                      style: GoogleFonts.montserrat(
                        fontSize: 9,
                        color: AppColors.brandGreen100,
                      ),
                    ),
                  ],
                ),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }
}

// ── Section Engagement ────────────────────────────────────────────────────────

class _SectionEngagementSection extends StatelessWidget {
  const _SectionEngagementSection({required this.sections});

  final List sections;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'COLLECTION BREAKDOWN',
          style: GoogleFonts.montserrat(
            fontSize: 10,
            fontWeight: FontWeight.w700,
            color: AppColors.mutedText,
            letterSpacing: 1.2,
          ),
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.surfaceWhite,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.borderSoft),
          ),
          child: Column(
            children: sections.asMap().entries.map<Widget>((entry) {
              final section = entry.value;
              final isActive = section.isCurrentlyActive as bool;
              return Padding(
                padding: EdgeInsets.only(
                  bottom: entry.key < sections.length - 1 ? 12 : 0,
                ),
                child: Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: isActive
                            ? AppColors.success
                            : AppColors.mutedText,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        section.title as String,
                        style: GoogleFonts.montserrat(
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                          color: AppColors.charcoal,
                        ),
                      ),
                    ),
                    Text(
                      isActive ? 'Active' : 'Inactive',
                      style: GoogleFonts.montserrat(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: isActive
                            ? AppColors.success
                            : AppColors.mutedText,
                      ),
                    ),
                  ],
                ),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }
}
