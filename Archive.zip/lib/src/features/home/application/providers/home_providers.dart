import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kc_admin/src/core/providers/firebase_providers.dart';
import 'package:kc_admin/src/features/design/application/providers/design_providers.dart';
import 'package:kc_admin/src/features/notification/application/providers/notification_providers.dart';
import 'package:kc_admin/src/features/stitching/application/providers/stitching_providers.dart';
import 'package:kc_admin/src/features/stitching/domain/models/stitching_order_model.dart';

// ─────────────────────────────────────────────
// Greeting provider
// ─────────────────────────────────────────────

/// Returns a time-based greeting (Morning/Afternoon/Evening).
final greetingProvider = Provider<String>((ref) {
  final hour = DateTime.now().hour;
  if (hour < 12) return 'Good morning';
  if (hour < 17) return 'Good afternoon';
  return 'Good evening';
});

// ─────────────────────────────────────────────
// Stitching counts by status
// ─────────────────────────────────────────────

/// Returns a map of [StitchingOrderStatus] → count for the active boutique.
final stitchingCountByStatusProvider = Provider<Map<StitchingOrderStatus, int>>(
  (ref) {
    final orders = ref.watch(adminOrderListProvider).valueOrNull ?? [];
    final map = <StitchingOrderStatus, int>{};
    for (final status in StitchingOrderStatus.values) {
      map[status] = orders.where((o) => o.status == status).length;
    }
    return map;
  },
);

/// Total number of active/pending stitching requests (not completed).
final requestedCountProvider = Provider<int>((ref) {
  final orders = ref.watch(adminOrderListProvider).valueOrNull ?? [];
  return orders.where((o) => o.status != StitchingOrderStatus.completed).length;
});

/// Total number of completed stitching requests.
final completedCountProvider = Provider<int>((ref) {
  final orders = ref.watch(adminOrderListProvider).valueOrNull ?? [];
  return orders.where((o) => o.status == StitchingOrderStatus.completed).length;
});

/// Alias for backwards compatibility.
final pendingOrderCountProvider = requestedCountProvider;

/// Number of orders that are ready for pickup.
final readyForPickupCountProvider = Provider<int>((ref) {
  final orders = ref.watch(adminOrderListProvider).valueOrNull ?? [];
  return orders.where((o) => o.status == StitchingOrderStatus.ready).length;
});

/// Orders received today.
final newOrdersTodayCountProvider = Provider<int>((ref) {
  final orders = ref.watch(adminOrderListProvider).valueOrNull ?? [];
  final today = DateTime.now();
  return orders.where((o) {
    final created = o.createdAt;
    return created.year == today.year &&
        created.month == today.month &&
        created.day == today.day;
  }).length;
});

// ─────────────────────────────────────────────
// Stream of Live Customer Favorites from Firestore
// ─────────────────────────────────────────────

final adminRecentFavoritesProvider =
    StreamProvider<List<Map<String, dynamic>>>((ref) {
      final firestore = ref.watch(firebaseFirestoreProvider);
      return firestore
          .collection('favorites')
          .orderBy('createdAt', descending: true)
          .limit(10)
          .snapshots()
          .map((snap) => snap.docs.map((doc) => doc.data()).toList())
          .handleError((_) => <Map<String, dynamic>>[]);
    });

// ─────────────────────────────────────────────
// Unified Live Recent Activity Feed (100% Real Data)
// ─────────────────────────────────────────────

enum AdminActivityCategory {
  stitchingRequest,
  stitchingStatus,
  favorite,
  newDesign,
  notification,
}

class AdminActivityItem {
  const AdminActivityItem({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.timestamp,
    required this.category,
    required this.icon,
    required this.color,
    this.associatedOrder,
  });

  final String id;
  final String title;
  final String subtitle;
  final DateTime timestamp;
  final AdminActivityCategory category;
  final IconData icon;
  final Color color;
  final StitchingOrderModel? associatedOrder;
}

/// Stream/Provider of combined multi-event live activities across the boutique.
/// 100% dynamic, derived exclusively from real Firestore collections.
final allActivityFeedProvider = Provider<List<AdminActivityItem>>((ref) {
  final items = <AdminActivityItem>[];

  // 1. Live Stitching Requests & Status Events
  final orders = ref.watch(adminOrderListProvider).valueOrNull ?? [];
  for (final o in orders) {
    if (o.status == StitchingOrderStatus.completed) {
      items.add(
        AdminActivityItem(
          id: 'status_${o.id}',
          title: 'Stitching Completed: #${o.orderNumber}',
          subtitle: 'Marked as completed • Customer notified',
          timestamp: o.updatedAt,
          category: AdminActivityCategory.stitchingStatus,
          icon: Icons.check_circle_rounded,
          color: const Color(0xFF2E7D32),
          associatedOrder: o,
        ),
      );
    } else {
      final titleName = o.designReferences.isNotEmpty
          ? o.designReferences.first.designName
          : 'Custom Stitching Request';
      items.add(
        AdminActivityItem(
          id: 'req_${o.id}',
          title: 'New Stitching Request: #${o.orderNumber}',
          subtitle: '$titleName created by customer',
          timestamp: o.createdAt,
          category: AdminActivityCategory.stitchingRequest,
          icon: Icons.pending_actions_rounded,
          color: const Color(0xFFE65100),
          associatedOrder: o,
        ),
      );
    }
  }

  // 2. Real Customer Favorites from Firestore `favorites` collection
  final rawFavs = ref.watch(adminRecentFavoritesProvider).valueOrNull ?? [];
  final designs = ref.watch(designListProvider).valueOrNull ?? [];
  final designMap = {for (final d in designs) d.id: d};

  for (final fav in rawFavs) {
    final designId = fav['designId'] as String? ?? '';
    final createdAtRaw = fav['createdAt'];
    DateTime timestamp = DateTime.now();
    if (createdAtRaw is Timestamp) {
      timestamp = createdAtRaw.toDate();
    }

    final matchedDesign = designMap[designId];
    final designName = matchedDesign?.name ?? 'Bespoke Item';

    items.add(
      AdminActivityItem(
        id: 'fav_${fav['id'] ?? designId}',
        title: 'Saved to Customer Favorites',
        subtitle: '"$designName" favorited by customer',
        timestamp: timestamp,
        category: AdminActivityCategory.favorite,
        icon: Icons.favorite_rounded,
        color: const Color(0xFFE91E63),
      ),
    );
  }

  // 3. Real Catalogue Designs
  for (final d in designs) {
    items.add(
      AdminActivityItem(
        id: 'design_${d.id}',
        title: 'New Catalogue Design',
        subtitle: '"${d.name}" published to collection',
        timestamp: d.createdAt,
        category: AdminActivityCategory.newDesign,
        icon: Icons.style_rounded,
        color: const Color(0xFF8E24AA),
      ),
    );
  }

  // 4. Real Notifications
  final notifications = ref.watch(notificationListProvider).valueOrNull ?? [];
  for (final n in notifications) {
    items.add(
      AdminActivityItem(
        id: 'notif_${n.id}',
        title: 'Notification Published',
        subtitle: n.title,
        timestamp: n.createdAt,
        category: AdminActivityCategory.notification,
        icon: Icons.campaign_rounded,
        color: const Color(0xFF1E88E5),
      ),
    );
  }

  // Sort newest first
  items.sort((a, b) => b.timestamp.compareTo(a.timestamp));
  return items;
});

/// Home dashboard limited subset (top 6 items)
final recentActivityFeedProvider = Provider<List<AdminActivityItem>>((ref) {
  final all = ref.watch(allActivityFeedProvider);
  return all.take(6).toList();
});

/// Legacy alias for backwards compatibility
final recentStitchingRequestsProvider = Provider<List<StitchingOrderModel>>((ref) {
  final orders = ref.watch(adminOrderListProvider).valueOrNull ?? [];
  final pending = orders
      .where((o) => o.status != StitchingOrderStatus.completed)
      .toList();
  pending.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
  return pending.take(3).toList(growable: false);
});
