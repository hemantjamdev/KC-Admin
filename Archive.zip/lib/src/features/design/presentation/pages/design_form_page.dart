import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../app/app_routes.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../category/application/providers/category_providers.dart';
import '../../application/providers/design_providers.dart';
import '../../domain/models/design_model.dart';
import '../widgets/design_image_picker_widget.dart';

/// Redesigned Product (Design) Form Page.
/// Features camera/gallery imagery, dynamic category module, hex color picker palette,
/// proper size chips, legible publish snackbar, and no ordering toggle switch.
class DesignFormPage extends ConsumerStatefulWidget {
  const DesignFormPage({super.key, this.existingDesign});

  final DesignModel? existingDesign;
  bool get isEditMode => existingDesign != null;

  @override
  ConsumerState<DesignFormPage> createState() => _DesignFormPageState();
}

class _DesignFormPageState extends ConsumerState<DesignFormPage> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _slugController = TextEditingController();
  final _priceController = TextEditingController();
  final _shortDescController = TextEditingController();
  final _descController = TextEditingController();
  final _thumbnailController = TextEditingController();
  final _customSizeController = TextEditingController();

  final _nameFocusNode = FocusNode();
  final _priceFocusNode = FocusNode();
  final _shortDescFocusNode = FocusNode();
  final _descFocusNode = FocusNode();

  bool _isSaving = false;
  bool _hasChanges = false;
  bool _allowDiscardPop = false;
  bool _slugEditedManually = false;

  String? _selectedCategoryId;
  List<String> _imageUrls = [];
  List<String> _tags = [];
  List<String> _keywords = [];
  List<String> _selectedColors = []; // Stores hex codes e.g. #D4AF37
  List<String> _selectedSizes = [];

  static const _presetColorSwatches = [
    {'name': 'Gold', 'hex': '#D4AF37', 'color': Color(0xFFD4AF37)},
    {'name': 'Emerald', 'hex': '#0F3625', 'color': Color(0xFF0F3625)},
    {'name': 'Crimson', 'hex': '#D32F2F', 'color': Color(0xFFD32F2F)},
    {'name': 'Sapphire', 'hex': '#1976D2', 'color': Color(0xFF1976D2)},
    {'name': 'Rose Pink', 'hex': '#E91E63', 'color': Color(0xFFE91E63)},
    {'name': 'Royal Purple', 'hex': '#8E24AA', 'color': Color(0xFF8E24AA)},
    {'name': 'Ivory', 'hex': '#F5F5DC', 'color': Color(0xFFF5F5DC)},
    {'name': 'Midnight Black', 'hex': '#1A1A1A', 'color': Color(0xFF1A1A1A)},
    {'name': 'Classic White', 'hex': '#FFFFFF', 'color': Color(0xFFFFFFFF)},
    {'name': 'Amber Orange', 'hex': '#E65100', 'color': Color(0xFFE65100)},
  ];

  static const _standardSizes = [
    'XS',
    'S',
    'M',
    'L',
    'XL',
    '2XL',
    '3XL',
    'Free Size / Custom',
  ];

  @override
  void initState() {
    super.initState();
    if (widget.isEditMode) {
      final d = widget.existingDesign!;
      _nameController.text = d.name;
      _slugController.text = d.slug;
      _priceController.text = d.price > 0 ? d.price.toStringAsFixed(0) : '';
      _shortDescController.text = d.shortDescription ?? '';
      _descController.text = d.description ?? '';
      _thumbnailController.text = d.thumbnailUrl ?? '';
      _selectedCategoryId = d.categoryId.isNotEmpty ? d.categoryId : null;
      _imageUrls = List.of(d.imageUrls);
      _tags = List.of(d.tags);
      _keywords = List.of(d.searchKeywords);
      _selectedColors = List.of(d.colors);
      _selectedSizes = List.of(d.sizes);
      _slugEditedManually = true;
    }

    _nameController.addListener(_onNameChanged);
    _nameController.addListener(_markDirty);
    _slugController.addListener(_markDirty);
    _priceController.addListener(_markDirty);
    _shortDescController.addListener(_markDirty);
    _descController.addListener(_markDirty);
  }

  @override
  void dispose() {
    _nameFocusNode.dispose();
    _priceFocusNode.dispose();
    _shortDescFocusNode.dispose();
    _descFocusNode.dispose();
    _nameController.dispose();
    _slugController.dispose();
    _priceController.dispose();
    _shortDescController.dispose();
    _descController.dispose();
    _thumbnailController.dispose();
    _customSizeController.dispose();
    super.dispose();
  }

  void _markDirty() {
    if (!_hasChanges) setState(() => _hasChanges = true);
  }

  void _onNameChanged() {
    if (!_slugEditedManually) {
      _slugController.text = _generateSlug(_nameController.text);
    }
  }

  String _generateSlug(String name) => name
      .toLowerCase()
      .replaceAll(RegExp(r'[^a-z0-9\s-]'), '')
      .trim()
      .replaceAll(RegExp(r'\s+'), '-')
      .replaceAll(RegExp(r'-+'), '-')
      .replaceAll(RegExp(r'^-|-$'), '');

  Future<bool> _onWillPop() async {
    if (!_hasChanges) return true;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Text(
          'Discard Unsaved Product?',
          style: GoogleFonts.playfairDisplay(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: AppColors.textPrimary,
          ),
        ),
        content: Text(
          'Unsaved product details will be discarded.',
          style: GoogleFonts.montserrat(
            fontSize: 13,
            color: AppColors.textMuted,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: Text(
              'Keep Editing',
              style: GoogleFonts.montserrat(color: AppColors.textMuted),
            ),
          ),
          ElevatedButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
            child: Text(
              'Discard',
              style: GoogleFonts.montserrat(color: Colors.white),
            ),
          ),
        ],
      ),
    );
    return confirmed == true;
  }

  void _showColorPickerDialog() {
    Color selectedColor = const Color(0xFFD4AF37);
    final hexTextController = TextEditingController(text: '#D4AF37');

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setDialogState) {
          return AlertDialog(
            backgroundColor: AppColors.surface,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            title: Row(
              children: [
                Container(
                  width: 24,
                  height: 24,
                  decoration: BoxDecoration(
                    color: selectedColor,
                    shape: BoxShape.circle,
                    border: Border.all(color: AppColors.surfaceBorder),
                  ),
                ),
                const SizedBox(width: 10),
                Text(
                  'Color Picker',
                  style: GoogleFonts.playfairDisplay(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Pick a color swatch or enter a custom HEX color code:',
                    style: GoogleFonts.montserrat(
                      fontSize: 12,
                      color: AppColors.textMuted,
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Preset Palette Grid
                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: _presetColorSwatches.map((item) {
                      final hex = item['hex'] as String;
                      final color = item['color'] as Color;
                      final isSelected = hexTextController.text.toUpperCase() == hex.toUpperCase();

                      return GestureDetector(
                        onTap: () {
                          setDialogState(() {
                            selectedColor = color;
                            hexTextController.text = hex;
                          });
                        },
                        child: Container(
                          width: 42,
                          height: 42,
                          decoration: BoxDecoration(
                            color: color,
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: isSelected ? AppColors.primary : AppColors.surfaceBorder,
                              width: isSelected ? 3 : 1,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.12),
                                blurRadius: 4,
                              ),
                            ],
                          ),
                          child: isSelected
                              ? Icon(
                                  Icons.check_rounded,
                                  size: 20,
                                  color: color.computeLuminance() > 0.5
                                      ? Colors.black
                                      : Colors.white,
                                )
                              : null,
                        ),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 20),

                  // Custom Hex Input Field
                  Text(
                    'Custom HEX Color Code',
                    style: GoogleFonts.montserrat(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Container(
                        width: 38,
                        height: 38,
                        decoration: BoxDecoration(
                          color: selectedColor,
                          shape: BoxShape.circle,
                          border: Border.all(color: AppColors.surfaceBorder),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: TextField(
                          controller: hexTextController,
                          style: GoogleFonts.montserrat(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                          ),
                          decoration: const InputDecoration(
                            hintText: '#HEX (e.g. #D4AF37)',
                            contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          ),
                          onChanged: (val) {
                            try {
                              String clean = val.trim().replaceAll('#', '');
                              if (clean.length == 6) {
                                setDialogState(() {
                                  selectedColor = Color(int.parse('FF$clean', radix: 16));
                                });
                              }
                            } catch (_) {}
                          },
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(ctx).pop(),
                child: const Text('Cancel'),
              ),
              ElevatedButton.icon(
                onPressed: () {
                  String hex = hexTextController.text.trim().toUpperCase();
                  if (!hex.startsWith('#')) hex = '#$hex';
                  if (hex.length == 7) {
                    setState(() {
                      if (!_selectedColors.contains(hex)) {
                        _selectedColors.add(hex);
                      }
                      _hasChanges = true;
                    });
                  }
                  Navigator.of(ctx).pop();
                },
                icon: const Icon(Icons.add_rounded, size: 18),
                label: const Text('Add Color'),
                style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary),
              ),
            ],
          );
        },
      ),
    );
  }

  Future<void> _navigateToCreateCategoryPage() async {
    final result = await context.push<dynamic>(AppRoutes.adminCategoryAdd);
    if (mounted) {
      ref.invalidate(categoryListProvider);
      if (result is String) {
        setState(() {
          _selectedCategoryId = result;
          _hasChanges = true;
        });
      }
    }
  }

  Future<void> _save() async {
    if (_isSaving) return;
    if (!(_formKey.currentState?.validate() ?? false)) return;

    const boutiqueId = 'boutique_01';

    setState(() => _isSaving = true);
    final now = DateTime.now();
    final price = double.tryParse(_priceController.text.trim()) ?? 0.0;

    final DesignModel design;
    if (widget.isEditMode) {
      design = widget.existingDesign!.copyWith(
        name: _nameController.text.trim(),
        slug: _slugController.text.trim(),
        categoryId: _selectedCategoryId ?? '',
        price: price,
        shortDescription: _shortDescController.text.trim().isEmpty
            ? null
            : _shortDescController.text.trim(),
        description: _descController.text.trim().isEmpty
            ? null
            : _descController.text.trim(),
        thumbnailUrl: _thumbnailController.text.trim().isEmpty
            ? null
            : _thumbnailController.text.trim(),
        imageUrls: _imageUrls,
        tags: _tags,
        searchKeywords: _keywords,
        colors: _selectedColors,
        sizes: _selectedSizes,
        isActive: true,
        updatedAt: now,
      );
      await ref.read(designMutationProvider.notifier).update(design);
    } else {
      design = DesignModel(
        id: 'design_${now.millisecondsSinceEpoch}',
        boutiqueId: boutiqueId,
        categoryId: _selectedCategoryId ?? '',
        name: _nameController.text.trim(),
        slug: _slugController.text.trim(),
        price: price,
        shortDescription: _shortDescController.text.trim().isEmpty
            ? null
            : _shortDescController.text.trim(),
        description: _descController.text.trim().isEmpty
            ? null
            : _descController.text.trim(),
        thumbnailUrl: _thumbnailController.text.trim().isEmpty
            ? null
            : _thumbnailController.text.trim(),
        imageUrls: _imageUrls,
        tags: _tags,
        searchKeywords: _keywords,
        colors: _selectedColors,
        sizes: _selectedSizes,
        sortOrder: 0,
        isActive: true,
        createdAt: now,
        updatedAt: now,
      );
      await ref.read(designMutationProvider.notifier).create(design);
    }

    if (!mounted) return;
    setState(() => _isSaving = false);

    // Highly Legible Custom Dark/Gold Snackbar
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        backgroundColor: const Color(0xFF1F2937), // Dark Charcoal
        content: Row(
          children: [
            const Icon(
              Icons.check_circle_rounded,
              color: Color(0xFFD4AF37), // Gold
              size: 22,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                widget.isEditMode
                    ? '"${design.name}" updated successfully.'
                    : '"${design.name}" published to catalogue.',
                style: GoogleFonts.montserrat(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
      ),
    );

    if (context.mounted) {
      context.pop();
    }
  }

  Future<void> _confirmDeleteFromForm() async {
    if (!widget.isEditMode) return;
    final d = widget.existingDesign!;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Text(
          'Delete Product?',
          style: GoogleFonts.playfairDisplay(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: AppColors.textPrimary,
          ),
        ),
        content: Text(
          'Are you sure you want to permanently delete "${d.name}"? This action cannot be undone.',
          style: GoogleFonts.montserrat(
            fontSize: 13,
            color: AppColors.textMuted,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: Text(
              'Cancel',
              style: GoogleFonts.montserrat(color: AppColors.textMuted),
            ),
          ),
          ElevatedButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
            child: Text(
              'Delete',
              style: GoogleFonts.montserrat(color: Colors.white),
            ),
          ),
        ],
      ),
    );

    if (confirmed == true && mounted) {
      setState(() => _isSaving = true);
      await ref.read(designMutationProvider.notifier).delete(d.id);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.all(16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          backgroundColor: const Color(0xFF1F2937),
          content: Row(
            children: [
              const Icon(
                Icons.check_circle_rounded,
                color: Color(0xFFD4AF37),
                size: 22,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  '"${d.name}" deleted successfully.',
                  style: GoogleFonts.montserrat(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
        ),
      );
      if (context.mounted) {
        setState(() => _allowDiscardPop = true);
        context.pop();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final categoriesAsync = ref.watch(categoryListProvider);
    final categories = categoriesAsync.valueOrNull ?? [];
    const boutiqueId = 'boutique_01';

    return PopScope(
      canPop: !_hasChanges || _allowDiscardPop,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        final canLeave = await _onWillPop();
        if (canLeave && context.mounted) {
          setState(() => _allowDiscardPop = true);
          context.pop();
        }
      },
      child: Scaffold(
        backgroundColor: AppColors.background,
        appBar: AppBar(
          backgroundColor: AppColors.background,
          elevation: 0,
          scrolledUnderElevation: 0,
          title: Text(
            widget.isEditMode ? 'Edit Product' : 'Add New Product',
            style: GoogleFonts.playfairDisplay(
              fontSize: 22,
              fontWeight: FontWeight.w700,
              color: AppColors.textPrimary,
            ),
          ),
          leading: IconButton(
            icon: const Icon(
              Icons.arrow_back_rounded,
              color: AppColors.textPrimary,
            ),
            onPressed: () async {
              final canLeave = await _onWillPop();
              if (canLeave && context.mounted) {
                setState(() => _allowDiscardPop = true);
                context.pop();
              }
            },
          ),
          actions: widget.isEditMode
              ? [
                  IconButton(
                    icon: const Icon(
                      Icons.delete_outline_rounded,
                      color: AppColors.error,
                    ),
                    tooltip: 'Delete Product',
                    onPressed: _confirmDeleteFromForm,
                  ),
                ]
              : null,
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.all(20),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 600),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // ── 1. Photography Section ──────────────────────────────
                      Text(
                        'GARMENT IMAGERY',
                        style: GoogleFonts.montserrat(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textMuted,
                          letterSpacing: 1.2,
                        ),
                      ),
                      const SizedBox(height: 10),
                      DesignImagePickerWidget(
                        boutiqueId: boutiqueId,
                        designId: widget.existingDesign?.id ?? 'new_design',
                        thumbnailUrl: _thumbnailController.text.isNotEmpty
                            ? _thumbnailController.text
                            : null,
                        imageUrls: _imageUrls,
                        onThumbnailChanged: (newThumb) {
                          setState(() {
                            _thumbnailController.text = newThumb ?? '';
                            _hasChanges = true;
                          });
                        },
                        onImageUrlsChanged: (newUrls) {
                          setState(() {
                            _imageUrls = newUrls;
                            _hasChanges = true;
                          });
                        },
                      ),

                      const SizedBox(height: 24),

                      // ── 2. Basic Info & Category Section ───────────────────
                      Text(
                        'PRODUCT INFORMATION',
                        style: GoogleFonts.montserrat(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textMuted,
                          letterSpacing: 1.2,
                        ),
                      ),
                      const SizedBox(height: 12),

                      // Product Title
                      TextFormField(
                        controller: _nameController,
                        focusNode: _nameFocusNode,
                        textInputAction: TextInputAction.next,
                        onFieldSubmitted: (_) => FocusScope.of(context).requestFocus(_priceFocusNode),
                        style: GoogleFonts.montserrat(
                          fontSize: 14,
                          color: AppColors.textPrimary,
                        ),
                        decoration: const InputDecoration(
                          labelText: 'Product Title *',
                          hintText: 'e.g. Royal Gold Embroidered Lehenga',
                        ),
                        validator: (v) {
                          if (v == null || v.trim().isEmpty) {
                            return 'Product title is required.';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 14),

                      // Price (INR)
                      TextFormField(
                        controller: _priceController,
                        focusNode: _priceFocusNode,
                        textInputAction: TextInputAction.next,
                        onFieldSubmitted: (_) => FocusScope.of(context).requestFocus(_shortDescFocusNode),
                        style: GoogleFonts.montserrat(
                          fontSize: 14,
                          color: AppColors.textPrimary,
                        ),
                        keyboardType: const TextInputType.numberWithOptions(
                          decimal: true,
                        ),
                        inputFormatters: [
                          FilteringTextInputFormatter.allow(
                            RegExp(r'^\d*\.?\d{0,2}'),
                          ),
                        ],
                        decoration: const InputDecoration(
                          labelText: 'Price (₹ INR)',
                          hintText: 'e.g. 18500',
                          prefixText: '₹ ',
                        ),
                      ),
                      const SizedBox(height: 14),

                      // Category Selector with + Quick Add Button
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Expanded(
                            child: DropdownButtonFormField<String>(
                              initialValue: _selectedCategoryId,
                              style: GoogleFonts.montserrat(
                                fontSize: 14,
                                color: AppColors.textPrimary,
                              ),
                              decoration: const InputDecoration(
                                labelText: 'Category',
                                hintText: 'Select category',
                              ),
                              items: categories.map((c) {
                                return DropdownMenuItem(
                                  value: c.id,
                                  child: Text(c.name),
                                );
                              }).toList(),
                              onChanged: (val) {
                                setState(() {
                                  _selectedCategoryId = val;
                                  _hasChanges = true;
                                });
                              },
                            ),
                          ),
                          const SizedBox(width: 10),
                          IconButton.filledTonal(
                            onPressed: _navigateToCreateCategoryPage,
                            icon: const Icon(Icons.add_rounded),
                            tooltip: 'Create New Category',
                            style: IconButton.styleFrom(
                              backgroundColor: AppColors.primary.withValues(
                                alpha: 0.1,
                              ),
                              foregroundColor: AppColors.primary,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),

                      // Short Description
                      TextFormField(
                        controller: _shortDescController,
                        focusNode: _shortDescFocusNode,
                        textInputAction: TextInputAction.next,
                        onFieldSubmitted: (_) => FocusScope.of(context).requestFocus(_descFocusNode),
                        style: GoogleFonts.montserrat(
                          fontSize: 14,
                          color: AppColors.textPrimary,
                        ),
                        maxLines: 2,
                        maxLength: 140,
                        decoration: const InputDecoration(
                          labelText: 'Short Summary / Artisan Note',
                          hintText:
                              'Brief summary of fabric, occasion, or craftsmanship.',
                        ),
                      ),
                      const SizedBox(height: 14),

                      // Full Description
                      TextFormField(
                        controller: _descController,
                        focusNode: _descFocusNode,
                        textInputAction: TextInputAction.done,
                        onFieldSubmitted: (_) => FocusScope.of(context).unfocus(),
                        style: GoogleFonts.montserrat(
                          fontSize: 14,
                          color: AppColors.textPrimary,
                        ),
                        maxLines: 4,
                        maxLength: 1000,
                        decoration: const InputDecoration(
                          labelText: 'Full Description',
                          hintText:
                              'Detailed description including fabric care, embellishments, and lining.',
                        ),
                      ),

                      const SizedBox(height: 24),

                      // ── 3. Hex Color Swatch Palette (Optional) ────────────
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'COLOR PALETTE (OPTIONAL)',
                            style: GoogleFonts.montserrat(
                              fontSize: 10,
                              fontWeight: FontWeight.w700,
                              color: AppColors.textMuted,
                              letterSpacing: 1.2,
                            ),
                          ),
                          TextButton.icon(
                            onPressed: _showColorPickerDialog,
                            icon: const Icon(
                              Icons.color_lens_outlined,
                              size: 16,
                            ),
                            label: Text(
                              '+ Add Color',
                              style: GoogleFonts.montserrat(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      if (_selectedColors.isEmpty)
                        Text(
                          'No colors selected yet. Tap "+ Add Color" to select swatches.',
                          style: GoogleFonts.montserrat(
                            fontSize: 12,
                            color: AppColors.textMuted,
                          ),
                        )
                      else
                        Wrap(
                          spacing: 10,
                          runSpacing: 10,
                          children: _selectedColors.map((hex) {
                            Color c = const Color(0xFFD4AF37);
                            try {
                              c = Color(
                                int.parse(
                                  hex.replaceFirst('#', 'FF'),
                                  radix: 16,
                                ),
                              );
                            } catch (_) {}

                            return Chip(
                              avatar: Container(
                                width: 18,
                                height: 18,
                                decoration: BoxDecoration(
                                  color: c,
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: AppColors.surfaceBorder,
                                  ),
                                ),
                              ),
                              label: Text(
                                hex,
                                style: GoogleFonts.montserrat(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              backgroundColor: AppColors.surface,
                              side: const BorderSide(
                                color: AppColors.surfaceBorder,
                              ),
                              onDeleted: () {
                                setState(() {
                                  _selectedColors.remove(hex);
                                  _hasChanges = true;
                                });
                              },
                            );
                          }).toList(),
                        ),

                      const SizedBox(height: 24),

                      // ── 4. Proper Size Options ─────────────────────────────
                      Text(
                        'AVAILABLE SIZES',
                        style: GoogleFonts.montserrat(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textMuted,
                          letterSpacing: 1.2,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: _standardSizes.map((size) {
                          final isSelected = _selectedSizes.contains(size);
                          return FilterChip(
                            selected: isSelected,
                            label: Text(size),
                            selectedColor: AppColors.primary,
                            checkmarkColor: AppColors.background,
                            labelStyle: GoogleFonts.montserrat(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              color: isSelected
                                  ? AppColors.background
                                  : AppColors.textPrimary,
                            ),
                            backgroundColor: AppColors.surface,
                            side: BorderSide(
                              color: isSelected
                                  ? AppColors.primary
                                  : AppColors.surfaceBorder,
                            ),
                            onSelected: (selected) {
                              setState(() {
                                if (selected) {
                                  _selectedSizes.add(size);
                                } else {
                                  _selectedSizes.remove(size);
                                }
                                _hasChanges = true;
                              });
                            },
                          );
                        }).toList(),
                      ),

                      const SizedBox(height: 36),

                      // ── 5. Publish CTA Button ─────────────────────────────
                      SizedBox(
                        width: double.infinity,
                        height: 52,
                        child: _isSaving
                            ? const Center(
                                child: CircularProgressIndicator(
                                  color: AppColors.primary,
                                  strokeWidth: 2.5,
                                ),
                              )
                            : ElevatedButton(
                                onPressed: _save,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: AppColors.primary,
                                  elevation: 2,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(14),
                                  ),
                                ),
                                child: Text(
                                  widget.isEditMode
                                      ? 'Save Changes'
                                      : 'Publish Product to Catalogue',
                                  style: GoogleFonts.montserrat(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w700,
                                    color: AppColors.background,
                                  ),
                                ),
                              ),
                      ),

                      const SizedBox(height: 36),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
