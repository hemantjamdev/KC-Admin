import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../../core/firebase/firestore_paths.dart';
import '../../domain/models/shop_profile_model.dart';

/// Singleton repository for the Kapada Creation shop profile.
/// Consistently reads and updates the single shop document.
class ShopProfileRepository {
  ShopProfileRepository({FirebaseFirestore? firestore})
    : _firestore = firestore ?? FirebaseFirestore.instance;

  final FirebaseFirestore _firestore;

  /// Stream the single Kapada Creation shop profile.
  Stream<ShopProfileModel> watchShopProfile() {
    return _firestore
        .collection(FirestorePaths.boutiques)
        .doc(ShopProfileModel.defaultId)
        .snapshots()
        .map((snap) {
          if (!snap.exists || snap.data() == null) {
            return ShopProfileModel.defaultProfile;
          }
          return ShopProfileModel.fromMap(snap.data()!, snap.id);
        })
        .handleError((_) => ShopProfileModel.defaultProfile);
  }

  /// Get current Kapada Creation shop profile.
  Future<ShopProfileModel> getShopProfile() async {
    try {
      final snap = await _firestore
          .collection(FirestorePaths.boutiques)
          .doc(ShopProfileModel.defaultId)
          .get();
      if (!snap.exists || snap.data() == null) {
        return ShopProfileModel.defaultProfile;
      }
      return ShopProfileModel.fromMap(snap.data()!, snap.id);
    } catch (_) {
      return ShopProfileModel.defaultProfile;
    }
  }

  /// Update the single Kapada Creation shop profile.
  Future<void> updateShopProfile(ShopProfileModel profile) async {
    await _firestore
        .collection(FirestorePaths.boutiques)
        .doc(ShopProfileModel.defaultId)
        .set({
          ...profile.toMap(),
          'updatedAt': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));
  }
}
