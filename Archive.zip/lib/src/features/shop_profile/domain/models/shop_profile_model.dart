import 'package:flutter/foundation.dart';

/// Singleton domain model representing Kapada Creation shop profile.
@immutable
class ShopProfileModel {
  const ShopProfileModel({
    required this.id,
    required this.name,
    required this.subtitle,
    this.phone,
    this.email,
    this.address,
    this.openingHours,
    this.description,
    this.logoUrl,
    this.isActive = true,
  });

  final String id;
  final String name;
  final String subtitle;
  final String? phone;
  final String? email;
  final String? address;
  final String? openingHours;
  final String? description;
  final String? logoUrl;
  final bool isActive;

  static const String defaultId = 'boutique_01';

  static const ShopProfileModel defaultProfile = ShopProfileModel(
    id: defaultId,
    name: 'Kapada Creation',
    subtitle: 'Luxury Bespoke Designer Apparel & Custom Tailoring',
    phone: '+91 98765 43210',
    email: 'contact@kapadacreation.com',
    address: 'Main Market, M.G. Road, Jaipur, Rajasthan 302001',
    openingHours: 'Mon - Sat: 10:00 AM - 8:30 PM',
    description: 'Premier fashion destination specializing in bespoke ethnic wear, couture bridal outfits, and tailored stitching.',
    logoUrl: null,
    isActive: true,
  );

  ShopProfileModel copyWith({
    String? id,
    String? name,
    String? subtitle,
    String? phone,
    String? email,
    String? address,
    String? openingHours,
    String? description,
    String? logoUrl,
    bool? isActive,
  }) {
    return ShopProfileModel(
      id: id ?? this.id,
      name: name ?? this.name,
      subtitle: subtitle ?? this.subtitle,
      phone: phone ?? this.phone,
      email: email ?? this.email,
      address: address ?? this.address,
      openingHours: openingHours ?? this.openingHours,
      description: description ?? this.description,
      logoUrl: logoUrl ?? this.logoUrl,
      isActive: isActive ?? this.isActive,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'subtitle': subtitle,
      if (phone != null) 'phone': phone,
      if (email != null) 'email': email,
      if (address != null) 'address': address,
      if (openingHours != null) 'openingHours': openingHours,
      if (description != null) 'description': description,
      if (logoUrl != null) 'logoUrl': logoUrl,
      'isActive': isActive,
    };
  }

  factory ShopProfileModel.fromMap(Map<String, dynamic> map, [String? docId]) {
    return ShopProfileModel(
      id: map['id'] as String? ?? docId ?? defaultId,
      name: map['name'] as String? ?? 'Kapada Creation',
      subtitle: map['subtitle'] as String? ?? '',
      phone: map['phone'] as String?,
      email: map['email'] as String?,
      address: map['address'] as String?,
      openingHours: map['openingHours'] as String?,
      description: map['description'] as String?,
      logoUrl: map['logoUrl'] as String?,
      isActive: map['isActive'] as bool? ?? true,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is ShopProfileModel &&
        other.id == id &&
        other.name == name &&
        other.subtitle == subtitle &&
        other.phone == phone &&
        other.email == email &&
        other.address == address &&
        other.openingHours == openingHours &&
        other.description == description &&
        other.logoUrl == logoUrl &&
        other.isActive == isActive;
  }

  @override
  int get hashCode {
    return Object.hash(
      id,
      name,
      subtitle,
      phone,
      email,
      address,
      openingHours,
      description,
      logoUrl,
      isActive,
    );
  }

  @override
  String toString() {
    return 'ShopProfileModel(id: $id, name: $name, subtitle: $subtitle, phone: $phone, email: $email, address: $address, openingHours: $openingHours, description: $description, logoUrl: $logoUrl, isActive: $isActive)';
  }
}
