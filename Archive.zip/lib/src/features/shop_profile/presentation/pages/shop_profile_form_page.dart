import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import '../../../../core/media/image_upload_service.dart';
import '../../../../core/theme/app_colors.dart';
import '../../application/providers/shop_profile_providers.dart';

import '../../domain/models/shop_profile_model.dart';
import '../widgets/customer_view_preview_dialog.dart';

/// Form screen to edit the single Kapada Creation studio profile details.
class ShopProfileFormPage extends ConsumerStatefulWidget {
  const ShopProfileFormPage({super.key});

  @override
  ConsumerState<ShopProfileFormPage> createState() =>
      _ShopProfileFormPageState();
}

class _ShopProfileFormPageState extends ConsumerState<ShopProfileFormPage> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameController;
  late final TextEditingController _subtitleController;
  late final TextEditingController _phoneController;
  late final TextEditingController _emailController;
  late final TextEditingController _addressController;
  late final TextEditingController _hoursController;
  late final TextEditingController _descController;
  late final TextEditingController _logoUrlController;

  final _nameFocusNode = FocusNode();
  final _subtitleFocusNode = FocusNode();
  final _addressFocusNode = FocusNode();
  final _phoneFocusNode = FocusNode();
  final _emailFocusNode = FocusNode();
  final _hoursFocusNode = FocusNode();
  final _descFocusNode = FocusNode();
  final _logoUrlFocusNode = FocusNode();

  bool _isSaving = false;
  bool _isUploadingImage = false;
  double _uploadProgress = 0.0;
  final ImageUploadService _uploadService = ImageUploadService();

  @override
  void initState() {
    super.initState();
    final profile = ref.read(shopProfileProvider);
    _nameController = TextEditingController(text: profile.name);
    _subtitleController = TextEditingController(text: profile.subtitle);
    _phoneController = TextEditingController(text: profile.phone ?? '');
    _emailController = TextEditingController(text: profile.email ?? '');
    _addressController = TextEditingController(text: profile.address ?? '');
    _hoursController = TextEditingController(text: profile.openingHours ?? '');
    _descController = TextEditingController(text: profile.description ?? '');
    _logoUrlController = TextEditingController(text: profile.logoUrl ?? '');

    // Rebuild live customer preview when form values change
    void updatePreview() => setState(() {});
    _nameController.addListener(updatePreview);
    _subtitleController.addListener(updatePreview);
    _phoneController.addListener(updatePreview);
    _addressController.addListener(updatePreview);
    _logoUrlController.addListener(updatePreview);
  }

  @override
  void dispose() {
    _nameFocusNode.dispose();
    _subtitleFocusNode.dispose();
    _addressFocusNode.dispose();
    _phoneFocusNode.dispose();
    _emailFocusNode.dispose();
    _hoursFocusNode.dispose();
    _descFocusNode.dispose();
    _logoUrlFocusNode.dispose();
    _nameController.dispose();
    _subtitleController.dispose();
    _phoneController.dispose();
    _emailController.dispose();
    _addressController.dispose();
    _hoursController.dispose();
    _descController.dispose();
    _logoUrlController.dispose();
    super.dispose();
  }

  void _previewCustomerView() {
    final draftProfile = ShopProfileModel(
      id: 'boutique_01',
      name: _nameController.text.trim(),
      subtitle: _subtitleController.text.trim(),
      phone: _phoneController.text.trim(),
      email: _emailController.text.trim(),
      address: _addressController.text.trim(),
      openingHours: _hoursController.text.trim(),
      description: _descController.text.trim(),
      logoUrl: _logoUrlController.text.trim().isEmpty
          ? null
          : _logoUrlController.text.trim(),
    );

    CustomerViewPreviewDialog.show(context, draftProfile);
  }

  Future<void> _saveProfile() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isSaving = true);
    try {
      final current = ref.read(shopProfileProvider);
      final updated = current.copyWith(
        name: _nameController.text.trim(),
        subtitle: _subtitleController.text.trim(),
        phone: _phoneController.text.trim(),
        email: _emailController.text.trim(),
        address: _addressController.text.trim(),
        openingHours: _hoursController.text.trim(),
        description: _descController.text.trim(),
        logoUrl: _logoUrlController.text.trim().isEmpty
            ? null
            : _logoUrlController.text.trim(),
      );

      await ref.read(shopProfileRepositoryProvider).updateShopProfile(updated);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Shop Profile updated successfully')),
        );
        context.pop();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to update shop profile: $e'),
            backgroundColor: AppColors.error,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.warmIvory,
      appBar: AppBar(
        backgroundColor: AppColors.surfaceWhite,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.charcoal),
          onPressed: () => context.pop(),
        ),
        title: Text(
          'Edit Studio Profile',
          style: GoogleFonts.playfairDisplay(
            fontSize: 20,
            fontWeight: FontWeight.w700,
            color: AppColors.charcoal,
          ),
        ),
        actions: [
          IconButton(
            onPressed: _previewCustomerView,
            icon: const Icon(Icons.phone_iphone_rounded, color: AppColors.primary),
            tooltip: 'Preview Customer App View',
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Kapada Creation Profile',
                  style: GoogleFonts.playfairDisplay(
                    fontSize: 22,
                    fontWeight: FontWeight.w700,
                    color: AppColors.charcoal,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'Update shop details displayed to customers across the application.',
                  style: GoogleFonts.montserrat(
                    fontSize: 13,
                    color: AppColors.mutedText,
                  ),
                ),
                const SizedBox(height: 16),

                // ── LIVE CUSTOMER VIEW PREVIEW CARD ─────────────────
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFAF7F2), // Warm cream card
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: const Color(0xFFEBE4D8), width: 1.2),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.05),
                        blurRadius: 12,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              const Icon(
                                Icons.local_florist_rounded,
                                size: 14,
                                color: AppColors.brandGreen900,
                              ),
                              const SizedBox(width: 6),
                              Text(
                                'KAPADA CREATION INFO',
                                style: GoogleFonts.playfairDisplay(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.brandGreen900,
                                  letterSpacing: 1.0,
                                ),
                              ),
                            ],
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: AppColors.brandGreen900.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Row(
                              children: [
                                const Icon(
                                  Icons.visibility_rounded,
                                  size: 11,
                                  color: AppColors.brandGreen900,
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  'Live Preview',
                                  style: GoogleFonts.montserrat(
                                    fontSize: 9,
                                    fontWeight: FontWeight.w700,
                                    color: AppColors.brandGreen900,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Logo Box
                          Container(
                            width: 80,
                            height: 100,
                            padding: const EdgeInsets.all(6),
                            decoration: BoxDecoration(
                              color: AppColors.surfaceWhite,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: const Color(0xFFD6C8B4),
                                width: 1.2,
                              ),
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  'Kapada',
                                  style: GoogleFonts.playfairDisplay(
                                    fontSize: 15,
                                    fontWeight: FontWeight.w800,
                                    color: AppColors.brandGreen900,
                                  ),
                                ),
                                Text(
                                  'CREATION',
                                  style: GoogleFonts.montserrat(
                                    fontSize: 7,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 1.4,
                                    color: AppColors.brandGreen800,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  'Est. 2015',
                                  style: GoogleFonts.montserrat(
                                    fontSize: 7,
                                    fontStyle: FontStyle.italic,
                                    color: AppColors.mutedText,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 10),

                          // Details
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  _nameController.text.trim().isNotEmpty
                                      ? _nameController.text.trim()
                                      : 'Kapada Creation',
                                  style: GoogleFonts.playfairDisplay(
                                    fontSize: 15,
                                    fontWeight: FontWeight.w700,
                                    color: AppColors.charcoal,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                const SizedBox(height: 3),
                                Text(
                                  _subtitleController.text.trim().isNotEmpty
                                      ? _subtitleController.text.trim()
                                      : 'Timeless elegance, stitched with love.',
                                  style: GoogleFonts.montserrat(
                                    fontSize: 10,
                                    color: AppColors.mutedText,
                                    height: 1.2,
                                  ),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                const SizedBox(height: 8),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Icon(
                                      Icons.location_on_outlined,
                                      size: 13,
                                      color: AppColors.charcoal,
                                    ),
                                    const SizedBox(width: 4),
                                    Expanded(
                                      child: Text(
                                        _addressController.text.trim().isNotEmpty
                                            ? _addressController.text.trim()
                                            : 'F-21, Green Park Extension, New Delhi',
                                        style: GoogleFonts.montserrat(
                                          fontSize: 10,
                                          color: AppColors.charcoal,
                                        ),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 4),
                                Row(
                                  children: [
                                    const Icon(
                                      Icons.phone_outlined,
                                      size: 12,
                                      color: AppColors.charcoal,
                                    ),
                                    const SizedBox(width: 4),
                                    Expanded(
                                      child: Text(
                                        _phoneController.text.trim().isNotEmpty
                                            ? _phoneController.text.trim()
                                            : '+91 98765 43210',
                                        style: GoogleFonts.montserrat(
                                          fontSize: 10,
                                          fontWeight: FontWeight.w500,
                                          color: AppColors.charcoal,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),

                          // Photo Box Preview
                          ClipRRect(
                            borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(32),
                              topRight: Radius.circular(32),
                              bottomLeft: Radius.circular(12),
                              bottomRight: Radius.circular(12),
                            ),
                            child: Image.network(
                              _logoUrlController.text.trim().isNotEmpty
                                  ? _logoUrlController.text.trim()
                                  : 'https://images.unsplash.com/photo-1558769132-cb1aea458c5e?q=80&w=600&auto=format&fit=crop',
                              width: 70,
                              height: 100,
                              fit: BoxFit.cover,
                              errorBuilder: (ctx, err, stack) => Container(
                                width: 70,
                                height: 100,
                                color: AppColors.brandGreen900,
                                child: const Icon(
                                  Icons.storefront_rounded,
                                  color: AppColors.brandGreen100,
                                  size: 24,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: _previewCustomerView,
                    icon: const Icon(
                      Icons.phone_iphone_rounded,
                      color: AppColors.primary,
                      size: 16,
                    ),
                    label: Text(
                      'Open Full Customer Mobile Frame Preview 📱',
                      style: GoogleFonts.montserrat(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: AppColors.primary,
                      ),
                    ),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: AppColors.primary, width: 1.2),
                      padding: const EdgeInsets.symmetric(vertical: 10),
                    ),
                  ),
                ),
                const SizedBox(height: 24),

                Text(
                  'Studio Name *',
                  style: GoogleFonts.montserrat(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppColors.charcoal,
                  ),
                ),
                const SizedBox(height: 6),
                TextFormField(
                  controller: _nameController,
                  focusNode: _nameFocusNode,
                  textInputAction: TextInputAction.next,
                  onFieldSubmitted: (_) => FocusScope.of(context).requestFocus(_subtitleFocusNode),
                  validator: (v) => v == null || v.trim().isEmpty
                      ? 'Studio name is required'
                      : null,
                  decoration: const InputDecoration(
                    hintText: 'e.g. Kapada Creation Studio',
                  ),
                ),

                const SizedBox(height: 16),
                Text(
                  'Tagline / Short Title',
                  style: GoogleFonts.montserrat(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppColors.charcoal,
                  ),
                ),
                const SizedBox(height: 6),
                TextFormField(
                  controller: _subtitleController,
                  focusNode: _subtitleFocusNode,
                  textInputAction: TextInputAction.next,
                  onFieldSubmitted: (_) => FocusScope.of(context).requestFocus(_addressFocusNode),
                  decoration: const InputDecoration(
                    hintText: 'e.g. Luxury Bespoke Designer Apparel & Custom Tailoring',
                  ),
                ),

                const SizedBox(height: 16),
                Text(
                  'Studio Address',
                  style: GoogleFonts.montserrat(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppColors.charcoal,
                  ),
                ),
                const SizedBox(height: 6),
                TextFormField(
                  controller: _addressController,
                  focusNode: _addressFocusNode,
                  textInputAction: TextInputAction.next,
                  onFieldSubmitted: (_) => FocusScope.of(context).requestFocus(_phoneFocusNode),
                  maxLines: 2,
                  decoration: const InputDecoration(
                    hintText: 'e.g. Main Market, M.G. Road, Jaipur, Rajasthan 302001',
                  ),
                ),

                const SizedBox(height: 16),
                Text(
                  'Phone Number',
                  style: GoogleFonts.montserrat(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppColors.charcoal,
                  ),
                ),
                const SizedBox(height: 6),
                TextFormField(
                  controller: _phoneController,
                  focusNode: _phoneFocusNode,
                  textInputAction: TextInputAction.next,
                  onFieldSubmitted: (_) => FocusScope.of(context).requestFocus(_emailFocusNode),
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(
                    hintText: 'e.g. +91 98765 43210',
                  ),
                ),

                const SizedBox(height: 16),
                Text(
                  'Email Address',
                  style: GoogleFonts.montserrat(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppColors.charcoal,
                  ),
                ),
                const SizedBox(height: 6),
                TextFormField(
                  controller: _emailController,
                  focusNode: _emailFocusNode,
                  textInputAction: TextInputAction.next,
                  onFieldSubmitted: (_) => FocusScope.of(context).requestFocus(_hoursFocusNode),
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(
                    hintText: 'e.g. contact@kapadacreation.com',
                  ),
                ),

                const SizedBox(height: 16),
                Text(
                  'Operational Hours',
                  style: GoogleFonts.montserrat(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppColors.charcoal,
                  ),
                ),
                const SizedBox(height: 6),
                TextFormField(
                  controller: _hoursController,
                  focusNode: _hoursFocusNode,
                  textInputAction: TextInputAction.next,
                  onFieldSubmitted: (_) => FocusScope.of(context).requestFocus(_descFocusNode),
                  decoration: const InputDecoration(
                    hintText: 'e.g. Mon - Sat: 10:00 AM - 8:30 PM',
                  ),
                ),

                const SizedBox(height: 16),
                Text(
                  'Studio Description & Craftsmanship',
                  style: GoogleFonts.montserrat(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppColors.charcoal,
                  ),
                ),
                const SizedBox(height: 6),
                TextFormField(
                  controller: _descController,
                  focusNode: _descFocusNode,
                  textInputAction: TextInputAction.done,
                  onFieldSubmitted: (_) => FocusScope.of(context).unfocus(),
                  maxLines: 3,
                  decoration: const InputDecoration(
                    hintText: 'e.g. Premier fashion destination specializing in bespoke ethnic wear, couture bridal outfits, and tailored stitching.',
                  ),
                ),

                const SizedBox(height: 16),
                Text(
                  'Boutique Photo & Interior Image',
                  style: GoogleFonts.montserrat(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppColors.charcoal,
                  ),
                ),
                const SizedBox(height: 6),
                _buildImageUploadSection(),

                const SizedBox(height: 32),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _isSaving ? null : _saveProfile,
                    child: _isSaving
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: AppColors.surfaceWhite,
                            ),
                          )
                        : const Text('Save Profile'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showImageSourcePicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surfaceWhite,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 36,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppColors.borderSoft,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                'Upload Studio / Interior Image',
                style: GoogleFonts.playfairDisplay(
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                  color: AppColors.charcoal,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'Select photo for customer store profile view',
                style: GoogleFonts.montserrat(
                  fontSize: 12,
                  color: AppColors.mutedText,
                ),
              ),
              const SizedBox(height: 20),
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: AppColors.primary.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(
                    Icons.camera_alt_rounded,
                    color: AppColors.primary,
                  ),
                ),
                title: Text(
                  'Take Photo (Camera)',
                  style: GoogleFonts.montserrat(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                    color: AppColors.charcoal,
                  ),
                ),
                subtitle: Text(
                  'Capture boutique photo using camera',
                  style: GoogleFonts.montserrat(
                    fontSize: 11,
                    color: AppColors.mutedText,
                  ),
                ),
                onTap: () {
                  Navigator.of(ctx).pop();
                  _pickAndUploadImage(ImageSource.camera);
                },
              ),
              const Divider(color: AppColors.borderSoft, height: 1),
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: AppColors.primary.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(
                    Icons.photo_library_rounded,
                    color: AppColors.primary,
                  ),
                ),
                title: Text(
                  'Choose from Gallery',
                  style: GoogleFonts.montserrat(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                    color: AppColors.charcoal,
                  ),
                ),
                subtitle: Text(
                  'Select existing photo from device storage',
                  style: GoogleFonts.montserrat(
                    fontSize: 11,
                    color: AppColors.mutedText,
                  ),
                ),
                onTap: () {
                  Navigator.of(ctx).pop();
                  _pickAndUploadImage(ImageSource.gallery);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _pickAndUploadImage(ImageSource source) async {
    final pickedFile = await _uploadService.pickImage(source: source);
    if (pickedFile == null) return;

    final file = File(pickedFile.path);
    final validationError = _uploadService.validateImageFile(file);
    if (validationError != null) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(validationError),
            backgroundColor: AppColors.error,
          ),
        );
      }
      return;
    }

    setState(() {
      _isUploadingImage = true;
      _uploadProgress = 0.0;
    });

    try {
      final fileId = _uploadService.generateFileId();
      final ext = file.path.split('.').last.toLowerCase();
      final storagePath = 'boutiques/boutique_01/shop_photo_$fileId.$ext';

      final result = await _uploadService.uploadImage(
        file: file,
        storagePath: storagePath,
        onProgress: (p) => setState(() => _uploadProgress = p),
      );

      setState(() {
        _logoUrlController.text = result.downloadUrl;
      });
    } catch (_) {
      // Local file path fallback if storage fails
      setState(() {
        _logoUrlController.text = file.path;
      });
    } finally {
      if (mounted) {
        setState(() => _isUploadingImage = false);
      }
    }
  }

  Widget _buildImageUploadSection() {
    final photoUrl = _logoUrlController.text.trim();
    final hasPhoto = photoUrl.isNotEmpty;
    final isLocalFile = hasPhoto && !photoUrl.startsWith('http');

    return Container(
      decoration: BoxDecoration(
        color: AppColors.surfaceWhite,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.borderSoft),
      ),
      padding: const EdgeInsets.all(12),
      child: Column(
        children: [
          if (hasPhoto) ...[
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: isLocalFile
                  ? Image.file(
                      File(photoUrl),
                      height: 160,
                      width: double.infinity,
                      fit: BoxFit.cover,
                    )
                  : Image.network(
                      photoUrl,
                      height: 160,
                      width: double.infinity,
                      fit: BoxFit.cover,
                      errorBuilder: (ctx, err, stack) => Container(
                        height: 160,
                        color: AppColors.brandGreen900,
                        child: const Icon(
                          Icons.broken_image_rounded,
                          color: AppColors.surfaceWhite,
                          size: 32,
                        ),
                      ),
                    ),
            ),
            const SizedBox(height: 10),
          ],
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _isUploadingImage ? null : _showImageSourcePicker,
                  icon: _isUploadingImage
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: AppColors.primary,
                          ),
                        )
                      : const Icon(Icons.add_a_photo_rounded, size: 18),
                  label: Text(
                    _isUploadingImage
                        ? 'Uploading (${(_uploadProgress * 100).toInt()}%)...'
                        : (hasPhoto ? 'Change Photo 📷' : 'Upload Studio Photo 📷'),
                    style: GoogleFonts.montserrat(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
              if (hasPhoto) ...[
                const SizedBox(width: 8),
                IconButton(
                  onPressed: () {
                    setState(() {
                      _logoUrlController.clear();
                    });
                  },
                  icon: const Icon(
                    Icons.delete_outline_rounded,
                    color: AppColors.error,
                  ),
                  tooltip: 'Remove Photo',
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}
