import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kc_admin/src/core/providers/firebase_providers.dart';
import 'package:kc_admin/src/features/shop_profile/application/providers/shop_profile_providers.dart';
import 'package:kc_admin/src/features/shop_profile/domain/models/shop_profile_model.dart';

// ─────────────────────────────────────────────
// Current admin user (from FirebaseAuth)
// ─────────────────────────────────────────────

/// Returns the current authenticated admin [User].
final adminCurrentUserProvider = Provider<User?>((ref) {
  return ref.watch(firebaseAuthProvider).currentUser;
});

/// Returns the display name of the current admin.
final adminDisplayNameProvider = Provider<String>((ref) {
  final user = ref.watch(adminCurrentUserProvider);
  if (user == null) return 'Admin';
  if (user.displayName != null && user.displayName!.isNotEmpty) {
    return user.displayName!;
  }
  // Fallback: first part of email
  final email = user.email ?? '';
  final localPart = email.split('@').first;
  return localPart.isNotEmpty
      ? '${localPart[0].toUpperCase()}${localPart.substring(1)}'
      : 'Admin';
});

/// Returns the email of the current admin.
final adminEmailProvider = Provider<String>((ref) {
  return ref.watch(adminCurrentUserProvider)?.email ?? '';
});

/// Returns the photoURL of the current admin.
final adminPhotoUrlProvider = Provider<String?>((ref) {
  return ref.watch(adminCurrentUserProvider)?.photoURL;
});

// ─────────────────────────────────────────────
// Shop profile (Kapada Creation profile)
// ─────────────────────────────────────────────

/// Provides the single Kapada Creation shop profile.
final adminShopProfileProvider = Provider<ShopProfileModel>((ref) {
  return ref.watch(shopProfileProvider);
});
