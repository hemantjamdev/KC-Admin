import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../../../../app/app_routes.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/navigation/navigation_extensions.dart';
import '../../../../core/widgets/app_loading_indicator.dart';
import '../../../customer/data/repositories/customer_repository_impl.dart';
import '../../../customer/domain/models/customer_model.dart';
import '../../application/providers/stitching_providers.dart';
import '../../domain/models/stitching_order_model.dart';
import '../widgets/order_status_update_sheet.dart';

/// Admin Stitching Order List page — streams live from Firestore via Riverpod.
class AdminStitchingOrderListPage extends ConsumerStatefulWidget {
  const AdminStitchingOrderListPage({super.key});

  @override
  ConsumerState<AdminStitchingOrderListPage> createState() =>
      _AdminStitchingOrderListPageState();
}

class _AdminStitchingOrderListPageState
    extends ConsumerState<AdminStitchingOrderListPage> {
  final TextEditingController _searchController = TextEditingController();
  final CustomerRepositoryImpl _customerRepo = CustomerRepositoryImpl();

  Map<String, CustomerModel> _customerCache = {};

  @override
  void initState() {
    super.initState();
    _loadCustomersCache();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadCustomersCache() async {
    try {
      final customers = await _customerRepo.getCustomersForAdmin();
      if (!mounted) return;
      setState(() {
        _customerCache = {for (var c in customers) c.id: c};
      });
    } catch (_) {}
  }

  Future<void> _openStatusSheet(StitchingOrderModel order) async {
    final updated = await OrderStatusUpdateSheet.show(
      context,
      order: order,
      updatedBy: 'admin',
    );

    if (updated == true && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Status updated for #${order.orderNumber}.'),
          backgroundColor: AppColors.surfaceBorder,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  Future<void> _confirmDelete(StitchingOrderModel order) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(
          'Delete Request?',
          style: GoogleFonts.playfairDisplay(
            color: AppColors.textPrimary,
            fontWeight: FontWeight.bold,
          ),
        ),
        content: Text(
          'Are you sure you want to delete request "${order.orderNumber}"?',
          style: GoogleFonts.montserrat(color: AppColors.textMuted),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: Text(
              'Cancel',
              style: GoogleFonts.montserrat(color: AppColors.textMuted),
            ),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: Text(
              'Delete',
              style: GoogleFonts.montserrat(color: AppColors.error),
            ),
          ),
        ],
      ),
    );

    if (confirmed == true && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Request #${order.orderNumber} deleted.'),
          backgroundColor: AppColors.surfaceBorder,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final ordersAsync = ref.watch(adminOrderListProvider);
    final filter = ref.watch(orderFilterProvider);
    final orders = ref.watch(filteredOrderListProvider);

    return PopScope(
      canPop: context.canPop(),
      onPopInvokedWithResult: (didPop, _) {
        if (didPop) return;
        if (context.mounted) context.popOrGo(AppRoutes.adminHome);
      },
      child: Scaffold(
        backgroundColor: AppColors.background,
        appBar: AppBar(
          backgroundColor: AppColors.background,
          elevation: 0,
          scrolledUnderElevation: 0,
          title: Text(
            'Stitching Requests',
            style: GoogleFonts.playfairDisplay(
              color: AppColors.textPrimary,
              fontSize: 22,
              fontWeight: FontWeight.w700,
            ),
          ),
          leading: IconButton(
            icon: const Icon(
              Icons.arrow_back_rounded,
              color: AppColors.textPrimary,
            ),
            onPressed: () => context.popOrGo(AppRoutes.adminHome),
          ),
        ),
        floatingActionButton: FloatingActionButton.extended(
          backgroundColor: AppColors.primary,
          foregroundColor: AppColors.background,
          elevation: 4,
          icon: const Icon(Icons.add_rounded, size: 20),
          label: Text(
            'Create Request',
            style: GoogleFonts.montserrat(
              fontWeight: FontWeight.w700,
              fontSize: 13,
            ),
          ),
          onPressed: () => context.push(AppRoutes.adminStitchingOrderAdd),
        ),
        body: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Search Input & Filter Chips
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextField(
                      controller: _searchController,
                      style: GoogleFonts.montserrat(
                        color: AppColors.textPrimary,
                        fontSize: 14,
                      ),
                      cursorColor: AppColors.primary,
                      decoration: InputDecoration(
                        hintText: 'Search by request number or garment name…',
                        hintStyle: GoogleFonts.montserrat(
                          color: AppColors.textHint,
                          fontSize: 13,
                        ),
                        prefixIcon: const Icon(
                          Icons.search_rounded,
                          color: AppColors.textMuted,
                          size: 20,
                        ),
                        suffixIcon: _searchController.text.isNotEmpty
                            ? IconButton(
                                icon: const Icon(
                                  Icons.clear_rounded,
                                  color: AppColors.textMuted,
                                  size: 20,
                                ),
                                onPressed: () {
                                  _searchController.clear();
                                  ref
                                      .read(orderFilterProvider.notifier)
                                      .search('');
                                },
                              )
                            : null,
                        filled: true,
                        fillColor: AppColors.surface,
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 12,
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14),
                          borderSide: const BorderSide(
                            color: AppColors.surfaceBorder,
                          ),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14),
                          borderSide: const BorderSide(
                            color: AppColors.surfaceBorder,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14),
                          borderSide: const BorderSide(
                            color: AppColors.primary,
                            width: 1.5,
                          ),
                        ),
                      ),
                      onChanged: (q) {
                        ref.read(orderFilterProvider.notifier).search(q);
                      },
                    ),
                    const SizedBox(height: 12),
                    // Status Filter Chips
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      physics: const BouncingScrollPhysics(),
                      child: Row(
                        children: [
                          _statusFilterChip(null, 'All Requests', filter),
                          const SizedBox(width: 8),
                          _statusFilterChip(
                            StitchingOrderStatus.received,
                            'Requested',
                            filter,
                          ),
                          const SizedBox(width: 8),
                          _statusFilterChip(
                            StitchingOrderStatus.stitching,
                            'In Progress',
                            filter,
                          ),
                          const SizedBox(width: 8),
                          _statusFilterChip(
                            StitchingOrderStatus.completed,
                            'Completed',
                            filter,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              // Orders List
              Expanded(
                child: RefreshIndicator(
                  color: AppColors.primary,
                  onRefresh: () async {
                    ref.invalidate(adminOrderListProvider);
                    await ref.read(adminOrderListProvider.future);
                  },
                  child: ordersAsync.when(
                    loading: () =>
                        const Center(child: AppLoadingIndicator(size: 32)),
                    error: (e, _) => ListView(
                      physics: const AlwaysScrollableScrollPhysics(),
                      children: [
                        SizedBox(
                          height: MediaQuery.of(context).size.height * 0.5,
                          child: Center(
                            child: Text(
                              'Failed to load stitching orders.\nPull down to retry.',
                              textAlign: TextAlign.center,
                              style: GoogleFonts.montserrat(
                                color: AppColors.textMuted,
                                fontSize: 13,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    data: (_) => orders.isEmpty
                        ? ListView(
                            physics: const AlwaysScrollableScrollPhysics(),
                            children: [
                              SizedBox(
                                height:
                                    MediaQuery.of(context).size.height * 0.5,
                                child: _buildEmptyState(filter),
                              ),
                            ],
                          )
                        : ListView.separated(
                            padding: const EdgeInsets.fromLTRB(20, 4, 20, 88),
                            physics: const AlwaysScrollableScrollPhysics(
                              parent: BouncingScrollPhysics(),
                            ),
                            itemCount: orders.length,
                            separatorBuilder: (_, _) =>
                                const SizedBox(height: 10),
                            itemBuilder: (context, i) {
                              final order = orders[i];
                              final customer = _customerCache[order.customerId];
                              final customerName =
                                  customer?.displayName ??
                                  'Customer #${order.customerId.substring(0, order.customerId.length.clamp(0, 6))}';

                              return _OrderCardTile(
                                order: order,
                                customerName: customerName,
                                onTapDetails: () => context.push(
                                  AppRoutes.adminStitchingOrderDetails,
                                  extra: order,
                                ),
                                onEdit: () => context.push(
                                  AppRoutes.adminStitchingOrderEdit,
                                  extra: order,
                                ),
                                onChangeStatus: () => _openStatusSheet(order),
                                onDelete: () => _confirmDelete(order),
                              );
                            },
                          ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _statusFilterChip(
    StitchingOrderStatus? status,
    String label,
    OrderFilterState filter,
  ) {
    final selected = filter.statusFilter == status;
    return GestureDetector(
      onTap: () =>
          ref.read(orderFilterProvider.notifier).filterByStatus(status),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: selected ? AppColors.primary : AppColors.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: selected ? AppColors.primary : AppColors.surfaceBorder,
          ),
        ),
        child: Text(
          label,
          style: GoogleFonts.montserrat(
            color: selected ? AppColors.background : AppColors.textMuted,
            fontSize: 12,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState(OrderFilterState filter) {
    final hasFilter =
        _searchController.text.isNotEmpty || filter.statusFilter != null;

    return Center(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 24),
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppColors.surfaceBorder),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.02),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                color: AppColors.primary.withValues(alpha: 0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                hasFilter
                    ? Icons.search_off_rounded
                    : Icons.design_services_outlined,
                color: AppColors.primary,
                size: 28,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              hasFilter
                  ? 'No Matching Requests'
                  : 'No Stitching Requests Yet',
              style: GoogleFonts.playfairDisplay(
                color: AppColors.textPrimary,
                fontSize: 18,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              hasFilter
                  ? 'No stitching requests match your search or selected status.'
                  : 'Customer stitching requests submitted in the app will appear here.',
              textAlign: TextAlign.center,
              style: GoogleFonts.montserrat(
                color: AppColors.textMuted,
                fontSize: 12,
                height: 1.4,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Stitching Request Card Tile ────────────────────────────────────────────────

class _OrderCardTile extends StatelessWidget {
  const _OrderCardTile({
    required this.order,
    required this.customerName,
    required this.onTapDetails,
    required this.onEdit,
    required this.onChangeStatus,
    required this.onDelete,
  });

  final StitchingOrderModel order;
  final String customerName;
  final VoidCallback onTapDetails;
  final VoidCallback onEdit;
  final VoidCallback onChangeStatus;
  final VoidCallback onDelete;

  String _formatDate(DateTime? dt) {
    if (dt == null) return 'N/A';
    return DateFormat('d MMM yyyy').format(dt);
  }

  @override
  Widget build(BuildContext context) {
    final isCompleted = order.status == StitchingOrderStatus.completed;
    final isActive = order.status != StitchingOrderStatus.received &&
        order.status != StitchingOrderStatus.completed;
    final statusColor = isCompleted
        ? const Color(0xFF2E7D32)
        : isActive
        ? const Color(0xFF1565C0)
        : const Color(0xFFE65100);
    final statusLabel = isCompleted
        ? 'Completed'
        : isActive
        ? order.status.adminLabel
        : 'Requested';

    final garmentTitle = order.designReferences.isNotEmpty
        ? order.designReferences.first.designName
        : 'Custom Stitching Request';

    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.surfaceBorder),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.02),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: ListTile(
        onTap: onTapDetails,
        contentPadding: const EdgeInsets.all(14),
        leading: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: statusColor.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Center(
            child: Icon(
              isCompleted
                  ? Icons.check_circle_rounded
                  : isActive
                  ? Icons.pending_actions_rounded
                  : Icons.fiber_new_rounded,
              size: 22,
              color: statusColor,
            ),
          ),
        ),
        title: Row(
          children: [
            Expanded(
              child: Text(
                '#${order.orderNumber}',
                style: GoogleFonts.montserrat(
                  color: AppColors.primary,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: statusColor.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Text(
                statusLabel,
                style: GoogleFonts.montserrat(
                  color: statusColor,
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 3),
            Text(
              garmentTitle,
              style: GoogleFonts.playfairDisplay(
                color: AppColors.textPrimary,
                fontSize: 15,
                fontWeight: FontWeight.w700,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 4),
            Row(
              children: [
                Text(
                  '$customerName • ${_formatDate(order.createdAt)}',
                  style: GoogleFonts.montserrat(
                    color: AppColors.textMuted,
                    fontSize: 11,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ],
        ),
        trailing: PopupMenuButton<String>(
          color: AppColors.surface,
          elevation: 3,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          icon: const Icon(
            Icons.more_vert_rounded,
            color: AppColors.textMuted,
            size: 20,
          ),
          itemBuilder: (_) => [
            PopupMenuItem(
              value: 'details',
              child: Row(
                children: [
                  const Icon(
                    Icons.visibility_outlined,
                    color: AppColors.primary,
                    size: 18,
                  ),
                  const SizedBox(width: 10),
                  Text(
                    'View Details',
                    style: GoogleFonts.montserrat(color: AppColors.textPrimary),
                  ),
                ],
              ),
            ),
            PopupMenuItem(
              value: 'status',
              child: Row(
                children: [
                  const Icon(
                    Icons.published_with_changes_rounded,
                    color: AppColors.primary,
                    size: 18,
                  ),
                  const SizedBox(width: 10),
                  Text(
                    'Update Status',
                    style: GoogleFonts.montserrat(color: AppColors.textPrimary),
                  ),
                ],
              ),
            ),
            PopupMenuItem(
              value: 'edit',
              child: Row(
                children: [
                  const Icon(
                    Icons.edit_rounded,
                    color: AppColors.primary,
                    size: 18,
                  ),
                  const SizedBox(width: 10),
                  Text(
                    'Edit Request',
                    style: GoogleFonts.montserrat(color: AppColors.textPrimary),
                  ),
                ],
              ),
            ),
          ],
          onSelected: (val) {
            switch (val) {
              case 'details':
                onTapDetails();
              case 'status':
                onChangeStatus();
              case 'edit':
                onEdit();
            }
          },
        ),
      ),
    );
  }
}
