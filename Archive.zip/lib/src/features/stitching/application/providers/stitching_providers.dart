import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kc_admin/src/core/providers/firebase_providers.dart';
import 'package:kc_admin/src/features/notification/application/providers/notification_providers.dart';
import 'package:kc_admin/src/features/notification/domain/models/notification_model.dart';
import 'package:kc_admin/src/features/stitching/data/repositories/stitching_order_firestore_repository.dart';
import 'package:kc_admin/src/features/stitching/domain/models/stitching_order_model.dart';
import 'package:kc_admin/src/features/stitching/domain/models/stitching_status_mutation_state.dart';

// ─────────────────────────────────────────────
// Repository provider
// ─────────────────────────────────────────────

final stitchingRepositoryProvider = Provider<StitchingOrderFirestoreRepository>(
  (ref) {
    return StitchingOrderFirestoreRepository(
      firestore: ref.watch(firebaseFirestoreProvider),
    );
  },
);

// ─────────────────────────────────────────────
// Order filter state
// ─────────────────────────────────────────────

class OrderFilterState {
  const OrderFilterState({this.searchQuery = '', this.statusFilter});
  final String searchQuery;
  final StitchingOrderStatus? statusFilter;

  OrderFilterState copyWith({
    String? searchQuery,
    Object? statusFilter = _sentinel,
  }) => OrderFilterState(
    searchQuery: searchQuery ?? this.searchQuery,
    statusFilter: statusFilter == _sentinel
        ? this.statusFilter
        : statusFilter as StitchingOrderStatus?,
  );
}

const _sentinel = Object();

// ─────────────────────────────────────────────
// Admin order list — live stream
// ─────────────────────────────────────────────

final adminOrderListProvider = StreamProvider<List<StitchingOrderModel>>((ref) {
  return ref.watch(stitchingRepositoryProvider).watchAdminOrders();
});

// ─────────────────────────────────────────────
// Order filter notifier (admin)
// ─────────────────────────────────────────────

final orderFilterProvider =
    NotifierProvider<OrderFilterNotifier, OrderFilterState>(
      OrderFilterNotifier.new,
    );

class OrderFilterNotifier extends Notifier<OrderFilterState> {
  @override
  OrderFilterState build() => const OrderFilterState();

  void search(String q) => state = state.copyWith(searchQuery: q.trim());

  void filterByStatus(StitchingOrderStatus? s) =>
      state = state.copyWith(statusFilter: s);

  void reset() => state = const OrderFilterState();
}

// ─────────────────────────────────────────────
// Derived: filtered admin order list
// ─────────────────────────────────────────────

final filteredOrderListProvider = Provider<List<StitchingOrderModel>>((ref) {
  final all = ref.watch(adminOrderListProvider).valueOrNull ?? [];
  final filter = ref.watch(orderFilterProvider);

  var result = all.where((o) {
    if (filter.statusFilter != null && o.status != filter.statusFilter) {
      return false;
    }
    if (filter.searchQuery.isNotEmpty) {
      final q = filter.searchQuery.toLowerCase();
      return o.orderNumber.toLowerCase().contains(q) ||
          o.designReferences.any(
            (d) => d.designName.toLowerCase().contains(q),
          ) ||
          (o.notes?.toLowerCase().contains(q) ?? false);
    }
    return true;
  }).toList();

  result.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
  return result;
});

// ─────────────────────────────────────────────
// Customer order list — live stream
// ─────────────────────────────────────────────

final customerOrderListProvider =
    StreamProvider.family<List<StitchingOrderModel>, String>((ref, customerId) {
      return ref
          .watch(stitchingRepositoryProvider)
          .watchCustomerOrders('default', customerId);
    });

// ─────────────────────────────────────────────
// Row-Level Stitching Status Mutation Notifier
// ─────────────────────────────────────────────

final stitchingStatusMutationProvider =
    NotifierProvider<
      StitchingStatusMutationNotifier,
      StitchingStatusMutationState
    >(StitchingStatusMutationNotifier.new);

class StitchingStatusMutationNotifier
    extends Notifier<StitchingStatusMutationState> {
  @override
  StitchingStatusMutationState build() => const StitchingStatusMutationState();

  Future<bool> updateStatus({
    required StitchingOrderModel order,
    required StitchingOrderStatus newStatus,
    required String updatedBy,
    String? note,
  }) async {
    final updatedRequests = Map<String, RowMutationState>.from(state.requests);
    updatedRequests[order.id] = const RowMutationState(
      status: MutationStatus.loading,
    );
    state = state.copyWith(requests: updatedRequests);

    try {
      final repo = ref.read(stitchingRepositoryProvider);
      await repo.updateOrderStatusWithHistory(
        orderId: order.id,
        newStatus: newStatus,
        note: note,
        updatedBy: updatedBy,
      );

      // Trigger private in-app notification creation for customer
      if (order.customerId.isNotEmpty) {
        final notifRepo = ref.read(notificationRepositoryProvider);
        final notifId = 'notif_${DateTime.now().millisecondsSinceEpoch}';
        final now = DateTime.now();
        final notif = NotificationModel(
          id: notifId,
          boutiqueId: order.boutiqueId.isNotEmpty
              ? order.boutiqueId
              : 'boutique_01',
          title: 'Stitching Update: ${order.orderNumber}',
          body:
              'Your tailoring request status has updated to: ${newStatus.customerLabel}',
          type: NotificationType.stitchingUpdate,
          status: NotificationStatus.published,
          audienceType: NotificationAudienceType.selectedCustomers,
          customerIds: [order.customerId],
          relatedEntityType: NotificationDestinationType.stitchingOrder,
          relatedEntityId: order.id,
          createdAt: now,
          updatedAt: now,
          publishedAt: now,
        );
        await notifRepo.createNotification(notif);
      }

      ref.invalidate(adminOrderListProvider);

      final successRequests = Map<String, RowMutationState>.from(
        state.requests,
      );
      successRequests[order.id] = const RowMutationState(
        status: MutationStatus.success,
      );
      state = state.copyWith(requests: successRequests);
      return true;
    } catch (e) {
      final failRequests = Map<String, RowMutationState>.from(state.requests);
      failRequests[order.id] = RowMutationState(
        status: MutationStatus.failure,
        errorMessage: e.toString(),
      );
      state = state.copyWith(requests: failRequests);
      return false;
    }
  }
}

// ─────────────────────────────────────────────
// Admin Mutation notifier for order creation
// ─────────────────────────────────────────────

final stitchingMutationProvider =
    NotifierProvider<StitchingMutationNotifier, AsyncValue<void>>(
      StitchingMutationNotifier.new,
    );

class StitchingMutationNotifier extends Notifier<AsyncValue<void>> {
  @override
  AsyncValue<void> build() => const AsyncValue.data(null);

  StitchingOrderFirestoreRepository get _repo =>
      ref.read(stitchingRepositoryProvider);

  Future<void> createOrder({
    required StitchingOrderModel order,
    required String initialNote,
    required String createdBy,
  }) async {
    state = const AsyncValue.loading();
    state = await AsyncValue.guard(
      () => _repo.createOrderWithHistory(
        order: order,
        initialNote: initialNote,
        createdBy: createdBy,
      ),
    );
    if (!state.hasError) ref.invalidate(adminOrderListProvider);
  }
}
