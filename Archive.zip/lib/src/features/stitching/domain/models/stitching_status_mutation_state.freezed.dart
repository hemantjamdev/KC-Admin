// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'stitching_status_mutation_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
  'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models',
);

/// @nodoc
mixin _$RowMutationState {
  MutationStatus get status => throw _privateConstructorUsedError;
  String? get errorMessage => throw _privateConstructorUsedError;

  /// Create a copy of RowMutationState
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $RowMutationStateCopyWith<RowMutationState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RowMutationStateCopyWith<$Res> {
  factory $RowMutationStateCopyWith(
    RowMutationState value,
    $Res Function(RowMutationState) then,
  ) = _$RowMutationStateCopyWithImpl<$Res, RowMutationState>;
  @useResult
  $Res call({MutationStatus status, String? errorMessage});
}

/// @nodoc
class _$RowMutationStateCopyWithImpl<$Res, $Val extends RowMutationState>
    implements $RowMutationStateCopyWith<$Res> {
  _$RowMutationStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of RowMutationState
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({Object? status = null, Object? errorMessage = freezed}) {
    return _then(
      _value.copyWith(
            status: null == status
                ? _value.status
                : status // ignore: cast_nullable_to_non_nullable
                      as MutationStatus,
            errorMessage: freezed == errorMessage
                ? _value.errorMessage
                : errorMessage // ignore: cast_nullable_to_non_nullable
                      as String?,
          )
          as $Val,
    );
  }
}

/// @nodoc
abstract class _$$RowMutationStateImplCopyWith<$Res>
    implements $RowMutationStateCopyWith<$Res> {
  factory _$$RowMutationStateImplCopyWith(
    _$RowMutationStateImpl value,
    $Res Function(_$RowMutationStateImpl) then,
  ) = __$$RowMutationStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({MutationStatus status, String? errorMessage});
}

/// @nodoc
class __$$RowMutationStateImplCopyWithImpl<$Res>
    extends _$RowMutationStateCopyWithImpl<$Res, _$RowMutationStateImpl>
    implements _$$RowMutationStateImplCopyWith<$Res> {
  __$$RowMutationStateImplCopyWithImpl(
    _$RowMutationStateImpl _value,
    $Res Function(_$RowMutationStateImpl) _then,
  ) : super(_value, _then);

  /// Create a copy of RowMutationState
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({Object? status = null, Object? errorMessage = freezed}) {
    return _then(
      _$RowMutationStateImpl(
        status: null == status
            ? _value.status
            : status // ignore: cast_nullable_to_non_nullable
                  as MutationStatus,
        errorMessage: freezed == errorMessage
            ? _value.errorMessage
            : errorMessage // ignore: cast_nullable_to_non_nullable
                  as String?,
      ),
    );
  }
}

/// @nodoc

class _$RowMutationStateImpl implements _RowMutationState {
  const _$RowMutationStateImpl({
    this.status = MutationStatus.idle,
    this.errorMessage,
  });

  @override
  @JsonKey()
  final MutationStatus status;
  @override
  final String? errorMessage;

  @override
  String toString() {
    return 'RowMutationState(status: $status, errorMessage: $errorMessage)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RowMutationStateImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.errorMessage, errorMessage) ||
                other.errorMessage == errorMessage));
  }

  @override
  int get hashCode => Object.hash(runtimeType, status, errorMessage);

  /// Create a copy of RowMutationState
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$RowMutationStateImplCopyWith<_$RowMutationStateImpl> get copyWith =>
      __$$RowMutationStateImplCopyWithImpl<_$RowMutationStateImpl>(
        this,
        _$identity,
      );
}

abstract class _RowMutationState implements RowMutationState {
  const factory _RowMutationState({
    final MutationStatus status,
    final String? errorMessage,
  }) = _$RowMutationStateImpl;

  @override
  MutationStatus get status;
  @override
  String? get errorMessage;

  /// Create a copy of RowMutationState
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$RowMutationStateImplCopyWith<_$RowMutationStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$StitchingStatusMutationState {
  Map<String, RowMutationState> get requests =>
      throw _privateConstructorUsedError;

  /// Create a copy of StitchingStatusMutationState
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $StitchingStatusMutationStateCopyWith<StitchingStatusMutationState>
  get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $StitchingStatusMutationStateCopyWith<$Res> {
  factory $StitchingStatusMutationStateCopyWith(
    StitchingStatusMutationState value,
    $Res Function(StitchingStatusMutationState) then,
  ) =
      _$StitchingStatusMutationStateCopyWithImpl<
        $Res,
        StitchingStatusMutationState
      >;
  @useResult
  $Res call({Map<String, RowMutationState> requests});
}

/// @nodoc
class _$StitchingStatusMutationStateCopyWithImpl<
  $Res,
  $Val extends StitchingStatusMutationState
>
    implements $StitchingStatusMutationStateCopyWith<$Res> {
  _$StitchingStatusMutationStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of StitchingStatusMutationState
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({Object? requests = null}) {
    return _then(
      _value.copyWith(
            requests: null == requests
                ? _value.requests
                : requests // ignore: cast_nullable_to_non_nullable
                      as Map<String, RowMutationState>,
          )
          as $Val,
    );
  }
}

/// @nodoc
abstract class _$$StitchingStatusMutationStateImplCopyWith<$Res>
    implements $StitchingStatusMutationStateCopyWith<$Res> {
  factory _$$StitchingStatusMutationStateImplCopyWith(
    _$StitchingStatusMutationStateImpl value,
    $Res Function(_$StitchingStatusMutationStateImpl) then,
  ) = __$$StitchingStatusMutationStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({Map<String, RowMutationState> requests});
}

/// @nodoc
class __$$StitchingStatusMutationStateImplCopyWithImpl<$Res>
    extends
        _$StitchingStatusMutationStateCopyWithImpl<
          $Res,
          _$StitchingStatusMutationStateImpl
        >
    implements _$$StitchingStatusMutationStateImplCopyWith<$Res> {
  __$$StitchingStatusMutationStateImplCopyWithImpl(
    _$StitchingStatusMutationStateImpl _value,
    $Res Function(_$StitchingStatusMutationStateImpl) _then,
  ) : super(_value, _then);

  /// Create a copy of StitchingStatusMutationState
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({Object? requests = null}) {
    return _then(
      _$StitchingStatusMutationStateImpl(
        requests: null == requests
            ? _value._requests
            : requests // ignore: cast_nullable_to_non_nullable
                  as Map<String, RowMutationState>,
      ),
    );
  }
}

/// @nodoc

class _$StitchingStatusMutationStateImpl
    implements _StitchingStatusMutationState {
  const _$StitchingStatusMutationStateImpl({
    final Map<String, RowMutationState> requests =
        const <String, RowMutationState>{},
  }) : _requests = requests;

  final Map<String, RowMutationState> _requests;
  @override
  @JsonKey()
  Map<String, RowMutationState> get requests {
    if (_requests is EqualUnmodifiableMapView) return _requests;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_requests);
  }

  @override
  String toString() {
    return 'StitchingStatusMutationState(requests: $requests)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$StitchingStatusMutationStateImpl &&
            const DeepCollectionEquality().equals(other._requests, _requests));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_requests));

  /// Create a copy of StitchingStatusMutationState
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$StitchingStatusMutationStateImplCopyWith<
    _$StitchingStatusMutationStateImpl
  >
  get copyWith =>
      __$$StitchingStatusMutationStateImplCopyWithImpl<
        _$StitchingStatusMutationStateImpl
      >(this, _$identity);
}

abstract class _StitchingStatusMutationState
    implements StitchingStatusMutationState {
  const factory _StitchingStatusMutationState({
    final Map<String, RowMutationState> requests,
  }) = _$StitchingStatusMutationStateImpl;

  @override
  Map<String, RowMutationState> get requests;

  /// Create a copy of StitchingStatusMutationState
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$StitchingStatusMutationStateImplCopyWith<
    _$StitchingStatusMutationStateImpl
  >
  get copyWith => throw _privateConstructorUsedError;
}
