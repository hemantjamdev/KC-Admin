import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../../core/firebase/firestore_paths.dart';
import '../../domain/models/notification_model.dart';

/// Firestore repository for notifications and read state.
class NotificationFirestoreRepository {
  NotificationFirestoreRepository({FirebaseFirestore? firestore})
    : _firestore = firestore ?? FirebaseFirestore.instance;

  final FirebaseFirestore _firestore;

  Stream<List<NotificationModel>> watchNotifications(String boutiqueId) {
    return _firestore
        .collection(FirestorePaths.notifications)
        .snapshots()
        .map((snapshot) {
          final list = snapshot.docs.map(_fromFirestore).toList();
          list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
          return list;
        })
        .handleError((_) => <NotificationModel>[]);
  }

  Future<void> createNotification(NotificationModel notification) async {
    await _firestore
        .collection(FirestorePaths.notifications)
        .doc(notification.id)
        .set(_toFirestore(notification, isCreate: true));
  }

  Future<void> updateNotification(NotificationModel notification) async {
    await _firestore
        .collection(FirestorePaths.notifications)
        .doc(notification.id)
        .update(_toFirestore(notification, isCreate: false));
  }

  Future<void> markAsRead(String notificationId, String customerId) async {
    final docId = '${notificationId}_$customerId';
    await _firestore
        .collection(FirestorePaths.notificationReads)
        .doc(docId)
        .set({
          'id': docId,
          'notificationId': notificationId,
          'customerId': customerId,
          'readAt': FieldValue.serverTimestamp(),
          'createdAt': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));
  }

  NotificationModel _fromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data() ?? {};
    final typeStr = data['type'] as String? ?? 'general';
    final type = NotificationType.values.firstWhere(
      (t) => t.name == typeStr,
      orElse: () => NotificationType.general,
    );

    final statusStr = data['status'] as String? ?? 'draft';
    final status = NotificationStatus.values.firstWhere(
      (s) => s.name == statusStr,
      orElse: () => NotificationStatus.draft,
    );

    final audienceStr =
        data['audienceType'] as String? ?? 'allBoutiqueCustomers';
    final audience = NotificationAudienceType.values.firstWhere(
      (a) => a.name == audienceStr,
      orElse: () => NotificationAudienceType.allBoutiqueCustomers,
    );

    final relTypeStr = data['relatedEntityType'] as String?;
    NotificationDestinationType? relatedEntityType;
    if (relTypeStr != null && relTypeStr.isNotEmpty) {
      relatedEntityType = NotificationDestinationType.values.firstWhere(
        (e) => e.name == relTypeStr,
        orElse: () => NotificationDestinationType.none,
      );
    }

    final createdAtRaw = data['createdAt'];
    final createdAt = createdAtRaw is Timestamp
        ? createdAtRaw.toDate()
        : DateTime.now();

    final updatedAtRaw = data['updatedAt'];
    final updatedAt = updatedAtRaw is Timestamp
        ? updatedAtRaw.toDate()
        : DateTime.now();

    final publishedAtRaw = data['publishedAt'];
    final publishedAt = publishedAtRaw is Timestamp
        ? publishedAtRaw.toDate()
        : null;

    final scheduledAtRaw = data['scheduledAt'];
    final scheduledAt = scheduledAtRaw is Timestamp
        ? scheduledAtRaw.toDate()
        : null;

    final expiresAtRaw = data['expiresAt'];
    final expiresAt = expiresAtRaw is Timestamp
        ? expiresAtRaw.toDate()
        : null;

    return NotificationModel(
      id: data['id'] as String? ?? doc.id,
      boutiqueId: data['boutiqueId'] as String? ?? '',
      branchId: data['branchId'] as String?,
      title: data['title'] as String? ?? '',
      body: data['body'] as String? ?? '',
      type: type,
      audienceType: audience,
      customerIds: List<String>.from(data['customerIds'] as List? ?? []),
      relatedEntityType: relatedEntityType,
      relatedEntityId: data['relatedEntityId'] as String?,
      status: status,
      scheduledAt: scheduledAt,
      publishedAt: publishedAt,
      expiresAt: expiresAt,
      createdAt: createdAt,
      updatedAt: updatedAt,
      createdBy: data['createdBy'] as String?,
      updatedBy: data['updatedBy'] as String?,
    );
  }

  Map<String, dynamic> _toFirestore(
    NotificationModel notification, {
    required bool isCreate,
  }) {
    return {
      'id': notification.id,
      'boutiqueId': notification.boutiqueId,
      'branchId': notification.branchId,
      'title': notification.title,
      'body': notification.body,
      'type': notification.type.name,
      'audienceType': notification.audienceType.name,
      'customerIds': notification.customerIds,
      'relatedEntityType': notification.relatedEntityType?.name,
      'relatedEntityId': notification.relatedEntityId,
      'status': notification.status.name,
      'scheduledAt': notification.scheduledAt != null
          ? Timestamp.fromDate(notification.scheduledAt!)
          : null,
      'publishedAt': notification.publishedAt != null
          ? Timestamp.fromDate(notification.publishedAt!)
          : (notification.status == NotificationStatus.published
              ? FieldValue.serverTimestamp()
              : null),
      'expiresAt': notification.expiresAt != null
          ? Timestamp.fromDate(notification.expiresAt!)
          : null,
      'updatedAt': FieldValue.serverTimestamp(),
      if (isCreate) 'createdAt': FieldValue.serverTimestamp(),
      'createdBy': notification.createdBy,
      'updatedBy': notification.updatedBy,
    };
  }
}
