import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kc_admin/src/core/providers/firebase_providers.dart';
import 'package:kc_admin/src/features/notification/data/repositories/notification_firestore_repository.dart';
import 'package:kc_admin/src/features/notification/data/services/admin_firebase_messaging_service.dart';
import 'package:kc_admin/src/features/notification/domain/models/notification_model.dart';

// ─────────────────────────────────────────────
// Repository & Service providers
// ─────────────────────────────────────────────

final notificationRepositoryProvider =
    Provider<NotificationFirestoreRepository>((ref) {
      return NotificationFirestoreRepository(
        firestore: ref.watch(firebaseFirestoreProvider),
      );
    });

final adminFirebaseMessagingServiceProvider =
    Provider<AdminFirebaseMessagingService>((ref) {
  return AdminFirebaseMessagingService();
});

// ─────────────────────────────────────────────
// Notification list — live stream
// ─────────────────────────────────────────────

final notificationListProvider = StreamProvider<List<NotificationModel>>((ref) {
  return ref
      .watch(notificationRepositoryProvider)
      .watchNotifications('boutique_01');
});

/// Count of notifications that are pending or unread.
final adminUnreadNotificationCountProvider = Provider<int>((ref) {
  final list = ref.watch(notificationListProvider).valueOrNull ?? [];
  return list.where((n) => n.status == NotificationStatus.draft).length;
});

// ─────────────────────────────────────────────
// Filter state
// ─────────────────────────────────────────────

enum NotificationReadFilter { all, unread, read }

class NotificationFilterState {
  const NotificationFilterState({
    this.searchQuery = '',
    this.typeFilter,
    this.statusFilter,
    this.audienceFilter,
    this.readFilter = NotificationReadFilter.all,
  });

  final String searchQuery;
  final NotificationType? typeFilter;
  final NotificationStatus? statusFilter;
  final NotificationAudienceType? audienceFilter;
  final NotificationReadFilter readFilter;

  NotificationFilterState copyWith({
    String? searchQuery,
    Object? typeFilter = _sentinel,
    Object? statusFilter = _sentinel,
    Object? audienceFilter = _sentinel,
    NotificationReadFilter? readFilter,
  }) => NotificationFilterState(
    searchQuery: searchQuery ?? this.searchQuery,
    typeFilter: typeFilter == _sentinel
        ? this.typeFilter
        : typeFilter as NotificationType?,
    statusFilter: statusFilter == _sentinel
        ? this.statusFilter
        : statusFilter as NotificationStatus?,
    audienceFilter: audienceFilter == _sentinel
        ? this.audienceFilter
        : audienceFilter as NotificationAudienceType?,
    readFilter: readFilter ?? this.readFilter,
  );
}

const _sentinel = Object();

final notificationFilterProvider =
    NotifierProvider<NotificationFilterNotifier, NotificationFilterState>(
      NotificationFilterNotifier.new,
    );

class NotificationFilterNotifier extends Notifier<NotificationFilterState> {
  @override
  NotificationFilterState build() => const NotificationFilterState();

  void search(String q) => state = state.copyWith(searchQuery: q.trim());

  void filterByType(NotificationType? t) =>
      state = state.copyWith(typeFilter: t);

  void filterByStatus(NotificationStatus? s) =>
      state = state.copyWith(statusFilter: s);

  void filterByAudience(NotificationAudienceType? a) =>
      state = state.copyWith(audienceFilter: a);

  void filterByRead(NotificationReadFilter r) =>
      state = state.copyWith(readFilter: r);

  void reset() => state = const NotificationFilterState();
}

// ─────────────────────────────────────────────
// Derived: filtered notification list
// ─────────────────────────────────────────────

final filteredNotificationListProvider = Provider<List<NotificationModel>>((
  ref,
) {
  final all = ref.watch(notificationListProvider).valueOrNull ?? [];
  final filter = ref.watch(notificationFilterProvider);

  var result = all.where((n) {
    if (filter.typeFilter != null && n.type != filter.typeFilter) return false;
    if (filter.statusFilter != null && n.status != filter.statusFilter) {
      return false;
    }
    if (filter.audienceFilter != null &&
        n.audienceType != filter.audienceFilter) {
      return false;
    }
    if (filter.searchQuery.isNotEmpty) {
      final q = filter.searchQuery.toLowerCase();
      return n.title.toLowerCase().contains(q) ||
          n.body.toLowerCase().contains(q);
    }
    return true;
  }).toList();

  result.sort((a, b) {
    final at = a.scheduledAt ?? a.publishedAt ?? a.createdAt;
    final bt = b.scheduledAt ?? b.publishedAt ?? b.createdAt;
    return bt.compareTo(at);
  });

  return result;
});

// ─────────────────────────────────────────────
// Mutation notifier (admin)
// ─────────────────────────────────────────────

final notificationMutationProvider =
    NotifierProvider<NotificationMutationNotifier, AsyncValue<void>>(
      NotificationMutationNotifier.new,
    );

class NotificationMutationNotifier extends Notifier<AsyncValue<void>> {
  @override
  AsyncValue<void> build() => const AsyncValue.data(null);

  NotificationFirestoreRepository get _repo =>
      ref.read(notificationRepositoryProvider);

  Future<void> create(NotificationModel notification) async {
    state = const AsyncValue.loading();
    state = await AsyncValue.guard(
      () => _repo.createNotification(notification),
    );
    if (!state.hasError) ref.invalidate(notificationListProvider);
  }

  Future<void> update(NotificationModel notification) async {
    state = const AsyncValue.loading();
    state = await AsyncValue.guard(
      () => _repo.updateNotification(notification),
    );
    if (!state.hasError) ref.invalidate(notificationListProvider);
  }

  Future<void> markAsRead(String notificationId, String customerId) async {
    state = const AsyncValue.loading();
    state = await AsyncValue.guard(
      () => _repo.markAsRead(notificationId, customerId),
    );
  }
}
