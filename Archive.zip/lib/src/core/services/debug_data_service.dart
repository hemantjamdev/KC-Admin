import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../firebase/firestore_paths.dart';
import '../providers/firebase_providers.dart';

/// Provider for [DebugDataService].
final debugDataServiceProvider = Provider<DebugDataService>((ref) {
  return DebugDataService(firestore: ref.watch(firebaseFirestoreProvider));
});

/// Service responsible for wiping Firestore collections for testing and debug purposes.
class DebugDataService {
  DebugDataService({required FirebaseFirestore firestore})
      : _firestore = firestore;

  final FirebaseFirestore _firestore;

  static const List<String> _targetCollections = [
    FirestorePaths.categories,
    FirestorePaths.designs,
    FirestorePaths.designAvailability,
    'products',
    FirestorePaths.sections,
    FirestorePaths.sectionItems,
    FirestorePaths.customers,
    FirestorePaths.stitchingOrders,
    FirestorePaths.stitchingOrderHistory,
    FirestorePaths.notifications,
    FirestorePaths.notificationReads,
    FirestorePaths.deviceTokens,
    'favorites',
    FirestorePaths.boutiques,
    FirestorePaths.branches,
    'shopProfile',
    FirestorePaths.admins,
  ];

  /// Wipes all documents across all application Firestore collections.
  /// Returns the total count of deleted documents.
  Future<int> deleteAllData() async {
    int totalDeleted = 0;
    for (final collectionName in _targetCollections) {
      final count = await _deleteCollection(collectionName);
      totalDeleted += count;
    }
    return totalDeleted;
  }

  Future<int> _deleteCollection(String collectionPath) async {
    int deletedCount = 0;
    while (true) {
      final snapshot =
          await _firestore.collection(collectionPath).limit(400).get();
      if (snapshot.docs.isEmpty) break;

      final batch = _firestore.batch();
      for (final doc in snapshot.docs) {
        batch.delete(doc.reference);
        deletedCount++;
      }
      await batch.commit();
    }
    return deletedCount;
  }
}
